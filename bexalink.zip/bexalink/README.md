# Bexalink

A URL shortener + CPM monetization platform (GPLinks-style): publishers shorten
links, visitors pass through a 3-step ad-supported interstitial, and publishers
earn per 1,000 valid views.

## Structure

```
bexalink/
├── database/
│   └── schema.sql          # Full Postgres schema (users, links, clicks, payouts, referrals, ads, fraud logs)
├── server/
│   ├── redirect-engine.js  # Core 3-step interstitial + referrer-safe final redirect
│   ├── redis-client.js     # Link cache, 24h unique-view dedup, rate limiting
│   ├── geo-cpm.js          # Country -> CPM rate resolution (cached)
│   ├── fraud-detection.js  # Bot UA / VPN / proxy / datacenter checks
│   ├── api-routes.js       # Shortening, dashboard stats, payouts, admin endpoints
│   └── views/              # EJS templates for the 3 interstitial steps
└── frontend/
    └── Dashboard.jsx        # Next.js + Tailwind publisher dashboard
```

## Redirection flow

```
/:code            Step 1 — landing + banner ad slots + 10s countdown
                    └─ records the monetized view (unique/valid check, CPM credit)
/:code/verify     Step 2 — Cloudflare Turnstile / reCAPTCHA v3
                    └─ on success, issues a short-lived signed token (HMAC, 2 min TTL)
/:code/continue   Step 3 — "Get Link" reveal page
/:code/go         Final hop — Referrer-Policy: no-referrer + client-side bounce,
                    so the destination site never sees Bexalink as the referrer
```

Each hop re-validates the signed token against the code + hashed IP, so the
funnel can't be skipped by requesting `/go` directly.

## Anti-fraud approach

- **Unique views**: `markUniqueView()` in Redis — one credited view per
  IP+link per 24h (`SET NX EX 86400`).
- **Bot/VPN/proxy filtering**: `fraud-detection.js` checks user-agent
  signatures plus a pluggable IP-intelligence provider (`ip-intel.js`,
  wire up IPQualityScore/IPHub/MaxMind here) for VPN, Tor, proxy, and
  datacenter ASN flags.
- **Rate limiting**: per-IP request throttle in Redis blunts scripted abuse
  before it reaches Postgres.
- Every rejected click is written to `fraud_logs` for admin review, and every
  click (valid or not) lands in the partitioned `clicks` table for auditing.

## Earnings pipeline

Raw events go into `clicks` in real time; a scheduled job (cron / worker)
rolls them up into `daily_earnings` per user/link/day, which is what the
dashboard reads for fast aggregate stats. `referral_earnings` records the 10%
lifetime commission whenever a referred user's daily rollup is written.

## What's stubbed vs. real code

This delivers real, wireable logic for schema, redirection, fraud checks, and
the dashboard UI. Three integration points are left as thin wrapper modules
you fill in with your chosen vendor:

- `server/ip-intel.js` — call your VPN/proxy detection + geo-IP provider
- `server/captcha.js` — call Cloudflare Turnstile's siteverify endpoint
- `server/db.js` — a standard `pg` Pool, and `server/auth-middleware.js` — your
  session/JWT + API-token auth guards

## Next steps to go to production

1. Wire the three stub modules above to real providers.
2. Add a worker (BullMQ, etc.) for the `clicks` -> `daily_earnings` rollup and
   for payout batch processing.
3. Put the redirect engine behind a CDN/edge cache for the link-resolution
   hot path, and run Postgres reads on a replica for the dashboard.
4. Add rate-limited Google OAuth + email/password auth (Passport.js or
   Lucia) feeding `users.google_id` / `users.password_hash`.
