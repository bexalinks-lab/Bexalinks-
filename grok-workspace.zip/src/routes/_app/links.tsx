import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useState } from "react";
import { listLinks } from "@/lib/server/links";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { CreateLinkDialog } from "@/components/create-link-dialog";
import { LinksTable } from "@/components/links-table";
import { QrDialog } from "@/components/qr-dialog";

export const Route = createFileRoute("/_app/links")({
  component: LinksPage,
});

function LinksPage() {
  const [open, setOpen] = useState(false);
  const [qr, setQr] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const links = useQuery({
    queryKey: ["links", query],
    queryFn: () => listLinks({ data: { query } }),
  });

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold">Links</h1>
          <p className="mt-1 text-sm text-muted-foreground">Every short path in this workspace.</p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus className="size-4" />
          New link
        </Button>
      </div>
      <div className="mt-6">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search destination or alias…"
          className="max-w-sm"
        />
      </div>
      <div className="mt-6 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]">
        {links.isPending ? (
          <div className="space-y-2 p-6">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : (
          <LinksTable links={links.data ?? []} onChange={() => void links.refetch()} onQr={setQr} />
        )}
      </div>
      <CreateLinkDialog open={open} onOpenChange={setOpen} onCreated={() => void links.refetch()} />
      <QrDialog code={qr} open={!!qr} onOpenChange={(o) => !o && setQr(null)} />
    </div>
  );
}
