import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { addDomain, listDomains, removeDomain, verifyDomain } from "@/lib/server/domains";
import { getWorkspace } from "@/lib/server/profile";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_app/domains")({
  component: DomainsPage,
});

function DomainsPage() {
  const [domain, setDomain] = useState("");
  const [busy, setBusy] = useState(false);
  const list = useQuery({ queryKey: ["domains"], queryFn: () => listDomains() });
  const workspace = useQuery({ queryKey: ["workspace"], queryFn: () => getWorkspace() });
  const canAdd = (workspace.data?.limits.domains ?? 0) > 0;

  async function add() {
    setBusy(true);
    try {
      await addDomain({ data: { domain } });
      setDomain("");
      toast.success("Domain added — verify DNS, then mark active.");
      void list.refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not add domain");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Custom domains</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Point a hostname at LinkShort and serve short paths on your own brand.
      </p>

      <div className="mt-8 rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]">
        <p className="text-sm font-semibold">Connect a domain</p>
        {!canAdd && workspace.data ? (
          <p className="mt-3 text-sm text-muted-foreground">
            Custom domains require Pro or Business.{" "}
            <Link to="/billing" className="font-semibold text-primary hover:underline">
              Upgrade plan
            </Link>
          </p>
        ) : (
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <Input
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              placeholder="links.yourbrand.com"
            />
            <Button onClick={() => void add()} disabled={busy}>
              Add domain
            </Button>
          </div>
        )}
        <pre className="mt-5 overflow-x-auto rounded-2xl bg-ink p-5 font-mono text-[13px] leading-relaxed text-ink-foreground">
          {`Type     CNAME
Name     links
Target   edge.lnk.sh`}
        </pre>
        <p className="mt-3 text-xs text-muted-foreground">
          Add the record at your DNS provider, then click Verify. This preview treats verification as a confirmation step.
        </p>
      </div>

      <div className="mt-6 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]">
        <p className="px-6 pt-5 text-sm font-semibold">Your domains</p>
        {list.isPending ? (
          <div className="p-6">
            <Skeleton className="h-12 w-full" />
          </div>
        ) : !list.data?.length ? (
          <p className="px-6 py-12 text-center text-sm text-muted-foreground">No custom domains connected yet.</p>
        ) : (
          <table className="mt-2 w-full text-sm">
            <thead>
              <tr className="text-[11px] uppercase tracking-wider text-muted-foreground">
                <th className="px-6 pb-2 text-left font-semibold">Domain</th>
                <th className="px-3 pb-2 text-left font-semibold">Status</th>
                <th className="px-6 pb-2" />
              </tr>
            </thead>
            <tbody>
              {list.data.map((d) => (
                <tr key={d.id} className="border-t border-border">
                  <td className="px-6 py-3 font-mono text-[13px]">{d.domain}</td>
                  <td className="px-3 py-3">
                    <Badge variant={d.status === "active" ? "success" : "muted"}>{d.status}</Badge>
                  </td>
                  <td className="px-6 py-3 text-right">
                    <div className="flex justify-end gap-2">
                      {d.status !== "active" ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            void verifyDomain({ data: { id: d.id } })
                              .then(() => {
                                toast.success("Domain verified");
                                void list.refetch();
                              })
                              .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Failed"))
                          }
                        >
                          Verify
                        </Button>
                      ) : null}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          void removeDomain({ data: { id: d.id } })
                            .then(() => {
                              toast.success("Domain removed");
                              void list.refetch();
                            })
                            .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Failed"))
                        }
                      >
                        Remove
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
