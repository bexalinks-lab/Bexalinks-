import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useState } from "react";
import { getWorkspace } from "@/lib/server/profile";
import { listLinks } from "@/lib/server/links";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { CreateLinkDialog } from "@/components/create-link-dialog";
import { LinksTable } from "@/components/links-table";
import { QrDialog } from "@/components/qr-dialog";
import { formatNumber } from "@/lib/utils";

export const Route = createFileRoute("/_app/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  const [open, setOpen] = useState(false);
  const [qr, setQr] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const workspace = useQuery({ queryKey: ["workspace"], queryFn: () => getWorkspace() });
  const links = useQuery({ queryKey: ["links"], queryFn: () => listLinks({ data: { query: "" } }) });

  const filtered = (links.data ?? [])
    .filter(
      (l) =>
        !query ||
        l.shortCode.toLowerCase().includes(query.toLowerCase()) ||
        l.originalUrl.toLowerCase().includes(query.toLowerCase()),
    )
    .slice(0, 8);

  const stats = workspace.data?.stats;

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold">Overview</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {workspace.data ? `${workspace.data.planName} plan` : "Your workspace"}
          </p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus className="size-4" />
          New link
        </Button>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {workspace.isPending
          ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-3xl" />)
          : [
              ["Total links", stats?.links ?? 0],
              ["Total clicks", stats?.clicks ?? 0],
              ["Active", stats?.active ?? 0],
              ["Domains", stats?.domains ?? 0],
            ].map(([label, n]) => (
              <div key={String(label)} className="rounded-[24px] border border-border bg-card p-5 shadow-[var(--shadow-card)]">
                <p className="font-display text-2xl font-semibold tabular-nums">{formatNumber(Number(n))}</p>
                <p className="mt-1 text-xs text-muted-foreground">{label}</p>
              </div>
            ))}
      </div>

      <div className="mt-8 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]">
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
          <p className="font-display text-lg font-semibold">Recent links</p>
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search…"
            className="h-9 max-w-[200px] rounded-xl"
          />
        </div>
        {links.isPending ? (
          <div className="space-y-2 px-5 pb-6">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : (
          <LinksTable
            links={filtered}
            dense
            onChange={() => {
              void links.refetch();
              void workspace.refetch();
            }}
            onQr={setQr}
          />
        )}
      </div>

      <CreateLinkDialog
        open={open}
        onOpenChange={setOpen}
        onCreated={() => {
          void links.refetch();
          void workspace.refetch();
        }}
      />
      <QrDialog code={qr} open={!!qr} onOpenChange={(o) => !o && setQr(null)} />
    </div>
  );
}
