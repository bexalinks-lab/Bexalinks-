import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { getWorkspace, saveProfileName } from "@/lib/server/profile";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_app/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const user = useCurrentUser();
  const workspace = useQuery({ queryKey: ["workspace"], queryFn: () => getWorkspace() });
  const [name, setName] = useState("");

  useEffect(() => {
    if (workspace.data?.name) setName(workspace.data.name);
    else if (user?.displayName) setName(user.displayName);
  }, [workspace.data, user]);

  async function save() {
    try {
      await saveProfileName({ data: { name } });
      toast.success("Settings saved");
      void workspace.refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not save");
    }
  }

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Account</h1>
      <p className="mt-1 text-sm text-muted-foreground">How you appear in this workspace.</p>
      <div className="mt-8 max-w-md space-y-4 rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]">
        <div>
          <Label htmlFor="name">Name</Label>
          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" value={user?.primaryEmail ?? ""} disabled />
        </div>
        <Button onClick={() => void save()}>Save changes</Button>
      </div>
    </div>
  );
}
