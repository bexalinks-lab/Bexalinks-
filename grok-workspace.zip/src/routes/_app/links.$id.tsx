import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { getLinkAnalytics } from "@/lib/server/links";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatNumber, shortLabel } from "@/lib/utils";

export const Route = createFileRoute("/_app/links/$id")({
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const { id } = Route.useParams();
  const q = useQuery({
    queryKey: ["analytics", id],
    queryFn: () => getLinkAnalytics({ data: { id } }),
  });

  if (q.isPending) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-3xl" />
          ))}
        </div>
        <Skeleton className="h-48 rounded-3xl" />
      </div>
    );
  }

  if (q.isError || !q.data) {
    return (
      <div>
        <p className="font-display text-xl">Could not load analytics.</p>
        <Button asChild variant="outline" className="mt-4">
          <Link to="/links">Back to links</Link>
        </Button>
      </div>
    );
  }

  const { link, total, unique, today, week, series, devices, browsers } = q.data;

  return (
    <div>
      <Button asChild variant="ghost" size="sm" className="-ml-2 mb-4">
        <Link to="/links">
          <ArrowLeft className="size-4" />
          Links
        </Link>
      </Button>
      <h1 className="font-display text-3xl font-semibold">{shortLabel(link.shortCode)}</h1>
      <p className="mt-1 truncate text-sm text-muted-foreground">{link.originalUrl}</p>

      <div className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          ["Total clicks", total],
          ["Unique mix", unique],
          ["Today", today],
          ["This week", week],
        ].map(([label, n]) => (
          <div key={String(label)} className="rounded-[24px] border border-border bg-card p-5 shadow-[var(--shadow-card)]">
            <p className="font-display text-2xl font-semibold tabular-nums">{formatNumber(Number(n))}</p>
            <p className="mt-1 text-xs text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]">
        <p className="text-sm font-semibold">Clicks · last 14 days</p>
        <div className="mt-4 h-44">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={series}>
              <XAxis dataKey="day" tickFormatter={(d) => String(d).slice(5)} tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} axisLine={false} tickLine={false} />
              <Tooltip
                cursor={{ fill: "color-mix(in oklab, var(--color-primary) 8%, transparent)" }}
                contentStyle={{ borderRadius: 12, borderColor: "var(--color-border)", fontSize: 12 }}
              />
              <Bar dataKey="count" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Breakdown title="By device" rows={devices} />
        <Breakdown title="By browser" rows={browsers} />
      </div>
    </div>
  );
}

function Breakdown({ title, rows }: { title: string; rows: { label: string; count: number }[] }) {
  const max = Math.max(1, ...rows.map((r) => r.count));
  return (
    <div className="rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]">
      <p className="text-sm font-semibold">{title}</p>
      <div className="mt-4 space-y-3">
        {rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">No clicks yet. Open the short link to record one.</p>
        ) : (
          rows.map((r) => (
            <div key={r.label} className="flex items-center gap-3 text-sm">
              <span className="w-20 capitalize text-muted-foreground">{r.label}</span>
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                <div className="h-full rounded-full bg-primary" style={{ width: `${(r.count / max) * 100}%` }} />
              </div>
              <span className="w-8 text-right tabular-nums text-xs font-semibold">{r.count}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
