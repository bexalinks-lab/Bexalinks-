import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { createApiKey, listApiKeys, revokeApiKey } from "@/lib/server/keys";
import { getWorkspace } from "@/lib/server/profile";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/_app/keys")({
  component: KeysPage,
});

function KeysPage() {
  const list = useQuery({ queryKey: ["keys"], queryFn: () => listApiKeys() });
  const workspace = useQuery({ queryKey: ["workspace"], queryFn: () => getWorkspace() });
  const [secret, setSecret] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const can = Boolean(workspace.data?.limits.api);

  async function generate() {
    setBusy(true);
    try {
      const res = await createApiKey();
      setSecret(res.secret);
      toast.success("New key generated — copy it now.");
      void list.refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not create key");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold">API keys</h1>
          <p className="mt-1 text-sm text-muted-foreground">Bearer tokens for POST /api/v1/shorten.</p>
        </div>
        <Button onClick={() => void generate()} disabled={busy || !can}>
          Generate key
        </Button>
      </div>

      {!can && workspace.data ? (
        <p className="mt-4 text-sm text-muted-foreground">
          API access requires Pro or Business.{" "}
          <Link to="/billing" className="font-semibold text-primary hover:underline">
            Upgrade
          </Link>
        </p>
      ) : null}

      {secret ? (
        <div className="mt-6 rounded-[24px] border border-primary/30 bg-primary/5 p-5">
          <p className="text-sm font-semibold">Copy this key. It will not be shown again.</p>
          <p className="mt-2 break-all font-mono text-sm">{secret}</p>
          <Button
            size="sm"
            className="mt-3"
            variant="secondary"
            onClick={() => {
              void navigator.clipboard.writeText(secret);
              toast.success("Copied");
            }}
          >
            Copy
          </Button>
        </div>
      ) : null}

      <div className="mt-6 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]">
        {list.isPending ? (
          <div className="p-6">
            <Skeleton className="h-12 w-full" />
          </div>
        ) : !list.data?.length ? (
          <p className="px-6 py-12 text-center text-sm text-muted-foreground">No API keys yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[11px] uppercase tracking-wider text-muted-foreground">
                <th className="px-6 py-3 text-left font-semibold">Key</th>
                <th className="px-3 py-3 text-left font-semibold">Created</th>
                <th className="px-3 py-3 text-left font-semibold">Requests</th>
                <th className="px-6 py-3" />
              </tr>
            </thead>
            <tbody>
              {list.data.map((k) => (
                <tr key={k.id} className="border-t border-border">
                  <td className="px-6 py-3 font-mono text-[13px]">{k.prefix}</td>
                  <td className="px-3 py-3 text-muted-foreground">{formatDate(k.createdAt)}</td>
                  <td className="px-3 py-3 tabular-nums">{k.uses}</td>
                  <td className="px-6 py-3 text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() =>
                        void revokeApiKey({ data: { id: k.id } })
                          .then(() => {
                            toast.success("Key revoked");
                            void list.refetch();
                          })
                          .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Failed"))
                      }
                    >
                      Revoke
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
