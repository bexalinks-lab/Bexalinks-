import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getWorkspace } from "@/lib/server/profile";
import { PricingGrid } from "@/components/pricing-grid";
import { Skeleton } from "@/components/ui/skeleton";
import { planById } from "@/lib/plans";

export const Route = createFileRoute("/_app/billing")({
  component: BillingPage,
});

function BillingPage() {
  const workspace = useQuery({ queryKey: ["workspace"], queryFn: () => getWorkspace() });
  const plan = planById(workspace.data?.planId ?? "free");

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Billing</h1>
      <p className="mt-1 text-sm text-muted-foreground">Plans are applied immediately. No card is charged in this product.</p>

      <div className="mt-8 rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]">
        <p className="text-sm font-semibold">Current plan</p>
        {workspace.isPending ? (
          <Skeleton className="mt-3 h-8 w-40" />
        ) : (
          <p className="mt-2 font-display text-2xl font-semibold">
            {plan.name}
            {plan.price ? <span className="ml-2 text-base font-medium text-muted-foreground">${plan.price}/mo</span> : <span className="ml-2 text-base font-medium text-muted-foreground">no cost</span>}
          </p>
        )}
      </div>

      <div className="mt-10">
        <h2 className="font-display text-xl font-semibold">Change plan</h2>
        <div className="mt-6">
          <PricingGrid currentPlan={workspace.data?.planId} />
        </div>
      </div>
    </div>
  );
}
