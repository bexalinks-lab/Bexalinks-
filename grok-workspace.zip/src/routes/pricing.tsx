import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PricingGrid } from "@/components/pricing-grid";

export const Route = createFileRoute("/pricing")({ component: PricingPage });

function PricingPage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-5 py-16">
        <div className="mx-auto max-w-xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">Pricing</p>
          <h1 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Plans that grow with your links</h1>
          <p className="mt-4 text-muted-foreground">Every plan includes fast redirects and QR codes. Upgrade is simulated — no card is charged.</p>
        </div>
        <div className="mt-12">
          <PricingGrid />
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
