import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { resolveShortLink } from "@/lib/server/links";
import { Logo } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/s/$code")({
  loader: ({ params }) => resolveShortLink({ data: { code: params.code } }),
  component: ShortLinkPage,
});

function ShortLinkPage() {
  const data = Route.useLoaderData();
  const { code } = Route.useParams();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState(data.kind === "ok" ? data.url : null);

  useEffect(() => {
    if (url) window.location.replace(url);
  }, [url]);

  async function unlock(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await resolveShortLink({ data: { code, password } });
      if (res.kind === "ok") setUrl(res.url);
      else if (res.kind === "bad_password") setError("That password does not match.");
      else if (res.kind === "blocked") setError(res.reason);
      else setError("This link is not available.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not open link");
    } finally {
      setBusy(false);
    }
  }

  if (url) {
    return (
      <GateShell>
        <h1 className="font-display text-2xl font-semibold">Redirecting</h1>
        <p className="mt-2 text-sm text-muted-foreground">Taking you to the destination.</p>
        <a href={url} className="mt-6 inline-block text-sm font-semibold text-primary hover:underline">
          Continue
        </a>
      </GateShell>
    );
  }

  if (data.kind === "missing") {
    return (
      <GateShell>
        <h1 className="font-display text-2xl font-semibold">No such link</h1>
        <p className="mt-2 text-sm text-muted-foreground">This short path is not in the ledger.</p>
        <Button asChild className="mt-6">
          <Link to="/">Make a new one</Link>
        </Button>
      </GateShell>
    );
  }

  if (data.kind === "blocked") {
    return (
      <GateShell>
        <h1 className="font-display text-2xl font-semibold">Link unavailable</h1>
        <p className="mt-2 text-sm text-muted-foreground">{data.reason}</p>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/">Home</Link>
        </Button>
      </GateShell>
    );
  }

  return (
    <GateShell>
      <h1 className="font-display text-2xl font-semibold">Protected link</h1>
      <p className="mt-2 text-sm text-muted-foreground">Enter the password to continue to the destination.</p>
      {error ? <p className="mt-4 text-sm text-destructive">{error}</p> : null}
      <form onSubmit={unlock} className="mt-6 space-y-3">
        <div>
          <Label htmlFor="pw">Password</Label>
          <Input
            id="pw"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoFocus
          />
        </div>
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Checking…" : "Continue"}
        </Button>
      </form>
    </GateShell>
  );
}

function GateShell({ children }: { children: React.ReactNode }) {
  return (
    <main className="grid min-h-screen place-items-center px-5">
      <div className="w-full max-w-md">
        <Logo />
        <div className="mt-8 rounded-[28px] border border-border bg-card p-8 shadow-[var(--shadow-card)]">{children}</div>
      </div>
    </main>
  );
}
