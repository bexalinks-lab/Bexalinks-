import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const Route = createFileRoute("/terms")({ component: TermsPage });

function TermsPage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-2xl px-5 py-16">
        <h1 className="font-display text-4xl font-semibold">Terms</h1>
        <div className="mt-6 space-y-4 text-sm leading-relaxed text-muted-foreground">
          <p>Use LinkShort for lawful destinations only. Do not shorten malware, phishing, or content that impersonates another party.</p>
          <p>Plans and upgrades in this product are simulated — no real charges are processed.</p>
          <p>We may disable a short path that is reported as abusive. You can pause or delete your own links at any time from the workspace.</p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
