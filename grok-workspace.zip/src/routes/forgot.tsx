import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Logo } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/forgot")({ component: ForgotPage });

function ForgotPage() {
  const [email, setEmail] = useState("");

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) {
      toast.error("Enter an email first.");
      return;
    }
    toast.success("If an account exists for that address, a reset note would be sent.");
  }

  return (
    <main className="grid min-h-screen place-items-center px-5 py-12">
      <div className="w-full max-w-md">
        <Logo />
        <div className="mt-8 rounded-[28px] border border-border bg-card p-8 shadow-[var(--shadow-card)]">
          <h1 className="font-display text-2xl font-semibold">Reset your password</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            We do not send mail from this preview. Submit an address and we will confirm the path.
          </p>
          <form onSubmit={onSubmit} className="mt-6 space-y-3">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@studio.com"
              />
            </div>
            <Button type="submit" className="w-full">
              Send reset link
            </Button>
          </form>
          <p className="mt-5 text-center text-sm">
            <Link to="/login" className="font-semibold text-primary hover:underline">
              Back to log in
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
