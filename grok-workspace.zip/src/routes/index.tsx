import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Activity,
  ArrowRight,
  Globe2,
  KeyRound,
  Lock,
  QrCode,
  ShieldCheck,
  Timer,
} from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { ShortenerBox } from "@/components/shortener-box";
import { PricingGrid } from "@/components/pricing-grid";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({ component: Home });

const FEATURES = [
  {
    icon: Globe2,
    title: "Custom domains",
    body: "Serve short paths on links.yourbrand.com. Keep the destination yours.",
  },
  {
    icon: Activity,
    title: "Click analytics",
    body: "Device, browser and a fourteen-day pulse the moment someone lands.",
  },
  {
    icon: Lock,
    title: "Password gates",
    body: "Hold a sensitive redirect behind a passphrase before it fires.",
  },
  {
    icon: Timer,
    title: "Expiry & caps",
    body: "Kill a link on a date, or after a fixed number of clicks.",
  },
  {
    icon: KeyRound,
    title: "Developer API",
    body: "Mint keys in the dashboard and shorten from your own code.",
  },
  {
    icon: ShieldCheck,
    title: "Quiet by default",
    body: "No cluttered dashboards. One workspace, one accent, real numbers.",
  },
];

function Home() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main>
        <section className="mx-auto max-w-6xl px-5 pb-16 pt-14 sm:pt-20">
          <div className="stagger-in max-w-3xl">
            <p className="mb-5 inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-primary">
              Short links, set in type
            </p>
            <h1 className="font-display text-5xl font-semibold tracking-tight sm:text-6xl lg:text-[72px]">
              Cut the URL.
              <br />
              Keep the story.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              LinkShort turns long destinations into branded paths — then shows who clicked, from where, and on what. Built for people who ship links as often as they ship code.
            </p>
          </div>
          <div className="mt-10 max-w-2xl">
            <ShortenerBox />
          </div>
          <div className="mt-14 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ["Fast redirects", "No interstitial junk"],
              ["Custom aliases", "Names you can remember"],
              ["QR in one tap", "Print-ready marks"],
              ["Real API", "Bearer keys, JSON in"],
            ].map(([t, s]) => (
              <div key={t} className="rounded-2xl border border-border bg-card px-4 py-4">
                <p className="text-sm font-semibold">{t}</p>
                <p className="mt-1 text-xs text-muted-foreground">{s}</p>
              </div>
            ))}
          </div>
        </section>

        <div className="hairline mx-auto max-w-6xl" />

        <section id="features" className="mx-auto max-w-6xl px-5 py-20">
          <div className="max-w-xl">
            <h2 className="font-display text-3xl font-semibold sm:text-4xl">Everything a growing team needs from a link</h2>
            <p className="mt-3 text-muted-foreground">
              Not just a redirect — a small piece of infrastructure for every URL you share.
            </p>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <article key={f.title} className="rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]">
                <div className="mb-4 grid size-10 place-items-center rounded-xl bg-secondary text-primary">
                  <f.icon className="size-4" />
                </div>
                <h3 className="font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="bg-ink text-ink-foreground">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-20 lg:grid-cols-2">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-haze">Analytics</p>
              <h2 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">See the click, not just the count</h2>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-haze">
                Every short path records device, browser and a daily pulse. Open a link in your workspace and the last fourteen days draw themselves.
              </p>
              <Button asChild variant="invert" className="mt-8">
                <Link to="/register">
                  Start a workspace
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
            </div>
            <div className="rounded-[28px] border border-white/10 bg-white/5 p-6">
              <div className="flex items-end justify-between">
                <p className="text-sm font-medium">Clicks · 14 days</p>
                <QrCode className="size-4 text-haze" />
              </div>
              <div className="mt-6 flex h-36 items-end gap-1.5">
                {[22, 34, 28, 51, 40, 63, 48, 72, 58, 80, 66, 90, 74, 88].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-t-sm bg-ink-foreground/80"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>
              <div className="mt-6 grid grid-cols-3 gap-3 text-xs">
                {[
                  ["Desktop", "62%"],
                  ["Mobile", "31%"],
                  ["Tablet", "7%"],
                ].map(([l, v]) => (
                  <div key={l} className="rounded-xl bg-white/5 px-3 py-2">
                    <p className="text-haze">{l}</p>
                    <p className="mt-1 font-semibold tabular-nums">{v}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-20">
          <div className="mx-auto max-w-xl text-center">
            <h2 className="font-display text-3xl font-semibold sm:text-4xl">Simple pricing, no theatre</h2>
            <p className="mt-3 text-muted-foreground">Start free. Upgrade when you need a domain or the API.</p>
          </div>
          <div className="mt-12">
            <PricingGrid />
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
