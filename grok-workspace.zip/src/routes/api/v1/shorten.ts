import { createFileRoute } from "@tanstack/react-router";
import { createLinkWithApiKey } from "@/lib/server/keys";

export const Route = createFileRoute("/api/v1/shorten")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const header = request.headers.get("authorization") ?? "";
        const token = header.replace(/^Bearer\s+/i, "").trim();
        if (!token) {
          return Response.json({ error: "Missing API key" }, { status: 401 });
        }
        let body: { url?: string; alias?: string } = {};
        try {
          body = (await request.json()) as { url?: string; alias?: string };
        } catch {
          return Response.json({ error: "Invalid JSON" }, { status: 400 });
        }
        if (!body.url) {
          return Response.json({ error: "url is required" }, { status: 400 });
        }
        try {
          const result = await createLinkWithApiKey(token, body.url, body.alias);
          const origin = new URL(request.url).origin;
          return Response.json({
            short_url: `${origin}/s/${result.shortCode}`,
            code: result.shortCode,
          });
        } catch (e) {
          const msg = e instanceof Error ? e.message : "Failed";
          const status = msg === "Invalid API key" ? 401 : 400;
          return Response.json({ error: msg }, { status });
        }
      },
    },
  },
});
