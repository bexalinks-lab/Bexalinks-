import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { getPlatformStats } from "@/lib/server/stats";
import { formatNumber } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const stats = useQuery({ queryKey: ["platform"], queryFn: () => getPlatformStats() });

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-5 py-16">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">Platform</p>
        <h1 className="mt-3 font-display text-4xl font-semibold">A quiet ledger</h1>
        <p className="mt-3 max-w-xl text-muted-foreground">
          Aggregate counts across this instance. Individual accounts stay private — no emails, no suspend switches, no other people's links.
        </p>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.isPending ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-3xl" />)
          ) : (
            [
              ["Links minted", stats.data?.links ?? 0],
              ["Clicks recorded", stats.data?.clicks ?? 0],
              ["Active paths", stats.data?.active ?? 0],
              ["Workspaces", stats.data?.workspaces ?? 0],
            ].map(([label, n]) => (
              <div key={String(label)} className="rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]">
                <p className="font-display text-3xl font-semibold tabular-nums">{formatNumber(Number(n))}</p>
                <p className="mt-1 text-sm text-muted-foreground">{label}</p>
              </div>
            ))
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
