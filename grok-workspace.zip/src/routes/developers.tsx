import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/developers")({ component: DevelopersPage });

function DevelopersPage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-5 py-16">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">Developer API</p>
        <h1 className="mt-3 font-display text-4xl font-semibold">Shorten from your own code</h1>
        <p className="mt-3 text-muted-foreground">
          Authenticate with a key from Dashboard → API keys, then POST a URL. Keys require Pro or Business.
        </p>

        <div className="mt-10 rounded-[24px] border border-border bg-card p-6">
          <p className="text-sm font-semibold">POST /api/v1/shorten</p>
          <pre className="mt-4 overflow-x-auto rounded-2xl bg-ink p-5 font-mono text-[13px] leading-relaxed text-ink-foreground">
            {`{
  "url": "https://example.com/page",
  "alias": "my-alias"
}

// 200
{
  "short_url": "https://your.host/s/X7k2P",
  "code": "X7k2P"
}`}
          </pre>
        </div>
        <div className="mt-4 rounded-[24px] border border-border bg-card p-6">
          <p className="text-sm font-semibold">Authentication</p>
          <pre className="mt-4 overflow-x-auto rounded-2xl bg-ink p-5 font-mono text-[13px] text-ink-foreground">
            Authorization: Bearer sk_live_your_api_key
          </pre>
        </div>
        <p className="mt-6 text-sm text-muted-foreground">
          Rate of use is not metered in this build. Generate a key after you upgrade, then call the endpoint from any HTTP client.
        </p>
        <Button asChild className="mt-8">
          <Link to="/keys">Open API keys</Link>
        </Button>
      </main>
      <SiteFooter />
    </div>
  );
}
