import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const Route = createFileRoute("/privacy")({ component: PrivacyPage });

function PrivacyPage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-2xl px-5 py-16">
        <h1 className="font-display text-4xl font-semibold">Privacy</h1>
        <div className="mt-6 space-y-4 text-sm leading-relaxed text-muted-foreground">
          <p>
            LinkShort stores the destination you submit, the short code we issue, and click metadata (time, device class, browser family, referrer). We do not sell this.
          </p>
          <p>
            Accounts use Google, X, or email and password. Your workspace data is scoped to your signed-in identity. Guest links created on the home page are unowned public redirects.
          </p>
          <p>Passwords on gated links are stored as hashes, never in the clear.</p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
