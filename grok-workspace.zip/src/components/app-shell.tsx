import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  CreditCard,
  Globe,
  KeyRound,
  LayoutDashboard,
  Link2,
  Menu,
  Settings,
} from "lucide-react";
import { useState } from "react";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Logo } from "./brand";
import { Button } from "./ui/button";
import { Sheet, SheetContent } from "./ui/sheet";
import { Skeleton } from "./ui/skeleton";
import { cn } from "@/lib/utils";

const ITEMS = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { to: "/links", label: "Links", icon: Link2 },
  { to: "/domains", label: "Domains", icon: Globe },
  { to: "/keys", label: "API keys", icon: KeyRound },
  { to: "/billing", label: "Billing", icon: CreditCard },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="flex flex-col gap-0.5">
      {ITEMS.map((item) => {
        const Icon = item.icon;
        const active =
          item.to === "/links"
            ? pathname === "/links" || pathname.startsWith("/links/")
            : pathname === item.to;
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
              active
                ? "bg-secondary text-foreground"
                : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground",
            )}
          >
            <Icon className="size-4" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function AppShell() {
  const { user, isPending } = useCurrentUserState();
  const [open, setOpen] = useState(false);

  if (isPending) {
    return (
      <div className="flex min-h-screen">
        <aside className="hidden w-[220px] border-r border-border p-5 md:block">
          <Skeleton className="h-8 w-32" />
          <div className="mt-8 space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        </aside>
        <div className="flex-1 p-8">
          <Skeleton className="h-8 w-48" />
          <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-3xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user) return <RedirectToSignIn />;

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="sticky top-0 hidden h-screen w-[232px] shrink-0 flex-col border-r border-border bg-background p-5 md:flex">
        <Logo />
        <div className="mt-8 flex-1">
          <NavItems />
        </div>
        <Link
          to="/"
          className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <BarChart3 className="size-4" />
          Marketing site
        </Link>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex h-16 items-center justify-between border-b border-border px-4 md:px-8">
          <button
            type="button"
            className="grid size-11 place-items-center rounded-xl border border-border md:hidden"
            onClick={() => setOpen(true)}
            aria-label="Open navigation"
          >
            <Menu className="size-4" />
          </button>
          <div className="hidden text-sm text-muted-foreground md:block">Workspace</div>
          <div className="ml-auto flex items-center gap-3">
            <Button asChild size="sm" variant="outline" className="hidden sm:inline-flex">
              <Link to="/">New from home</Link>
            </Button>
            <UserButton />
          </div>
        </div>
        <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 md:px-8">
          <Outlet />
        </main>
      </div>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left">
          <Logo />
          <div className="mt-8">
            <NavItems onNavigate={() => setOpen(false)} />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
