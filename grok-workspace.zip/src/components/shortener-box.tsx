import { useState } from "react";
import { ArrowRight, Copy, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { createLink, shortenPublic } from "@/lib/server/links";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { shortHref, shortLabel } from "@/lib/utils";

export function ShortenerBox() {
  const { user, isPending } = useCurrentUserState();
  const [url, setUrl] = useState("");
  const [alias, setAlias] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ code: string; original: string } | null>(null);
  const [copied, setCopied] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!url.trim()) {
      toast.error("Paste a URL first.");
      return;
    }
    setBusy(true);
    try {
      const payload = { url: url.trim(), alias: alias.trim() || undefined };
      const created =
        user && !isPending
          ? await createLink({ data: payload })
          : await shortenPublic({ data: payload });
      setResult({ code: created.shortCode, original: created.originalUrl });
      setUrl("");
      setAlias("");
      toast.success(user ? "Link added to your workspace." : "Short link ready.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not shorten that URL");
    } finally {
      setBusy(false);
    }
  }

  async function copy() {
    if (!result) return;
    const href = shortHref(result.code);
    try {
      await navigator.clipboard.writeText(href);
      setCopied(true);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(false), 1600);
    } catch {
      toast.error("Could not copy");
    }
  }

  return (
    <div className="rounded-[28px] border border-border bg-card p-4 shadow-[var(--shadow-card)] sm:p-5">
      <form onSubmit={onSubmit} className="flex flex-col gap-3">
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Paste a long URL — https://…"
            className="h-12 flex-1 rounded-2xl px-4"
            inputMode="url"
            autoComplete="off"
          />
          <Button type="submit" size="lg" className="h-12 rounded-2xl sm:w-auto" disabled={busy}>
            {busy ? "Shortening…" : "Shorten"}
            <ArrowRight className="size-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="shrink-0 font-mono text-xs">alias</span>
          <Input
            value={alias}
            onChange={(e) => setAlias(e.target.value)}
            placeholder="custom-slug (optional)"
            className="h-10 rounded-xl font-mono text-sm"
          />
        </div>
      </form>
      {result ? (
        <div className="mt-4 flex flex-col gap-3 rounded-2xl border border-primary/30 bg-primary/5 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <p className="truncate font-mono text-sm font-semibold text-primary">{shortLabel(result.code)}</p>
            <p className="truncate text-xs text-muted-foreground">{result.original}</p>
          </div>
          <Button type="button" size="sm" variant="secondary" onClick={() => void copy()}>
            {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
            {copied ? "Copied" : "Copy"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
