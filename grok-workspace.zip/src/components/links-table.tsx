import { BarChart3, Copy, Pause, Play, QrCode, Trash2 } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { useState, type ReactNode } from "react";
import type { LinkDTO } from "@/lib/server/links";
import { deleteLink, toggleLink } from "@/lib/server/links";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { formatDate, formatNumber, shortHref, shortLabel } from "@/lib/utils";

export function LinksTable({
  links,
  dense,
  onChange,
  onQr,
}: {
  links: LinkDTO[];
  dense?: boolean;
  onChange: () => void;
  onQr: (code: string) => void;
}) {
  const [pendingDelete, setPendingDelete] = useState<LinkDTO | null>(null);

  async function copy(code: string) {
    try {
      await navigator.clipboard.writeText(shortHref(code));
      toast.success("Copied");
    } catch {
      toast.error("Could not copy");
    }
  }

  async function toggle(id: string) {
    try {
      const res = await toggleLink({ data: { id } });
      toast.success(res.status === "active" ? "Link enabled" : "Link paused");
      onChange();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not update");
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    try {
      await deleteLink({ data: { id: pendingDelete.id } });
      toast.success("Link deleted");
      setPendingDelete(null);
      onChange();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not delete");
    }
  }

  if (!links.length) {
    return (
      <div className="px-6 py-16 text-center">
        <p className="font-display text-lg">No links yet</p>
        <p className="mt-1 text-sm text-muted-foreground">Create one and it will land here, with click counts attached.</p>
      </div>
    );
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead>
            <tr className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              <th className="px-5 pb-3 pt-4 font-semibold">Short link</th>
              {!dense ? <th className="px-3 pb-3 pt-4 font-semibold">Destination</th> : null}
              <th className="px-3 pb-3 pt-4 font-semibold">Clicks</th>
              {!dense ? <th className="px-3 pb-3 pt-4 font-semibold">Created</th> : null}
              <th className="px-3 pb-3 pt-4 font-semibold">Status</th>
              <th className="px-3 pb-3 pt-4 font-semibold" />
            </tr>
          </thead>
          <tbody>
            {links.map((l) => (
              <tr key={l.id} className="border-t border-border/80 hover:bg-muted/40">
                <td className="px-5 py-3.5">
                  <a
                    href={shortHref(l.shortCode)}
                    target="_blank"
                    rel="noreferrer"
                    className="font-mono text-[13px] font-semibold text-primary hover:underline"
                  >
                    {shortLabel(l.shortCode)}
                  </a>
                </td>
                {!dense ? (
                  <td className="max-w-[240px] truncate px-3 py-3.5 text-muted-foreground">{l.originalUrl}</td>
                ) : null}
                <td className="px-3 py-3.5 tabular-nums">{formatNumber(l.clicks)}</td>
                {!dense ? <td className="px-3 py-3.5 text-muted-foreground">{formatDate(l.createdAt)}</td> : null}
                <td className="px-3 py-3.5">
                  <Badge variant={l.status === "active" ? "success" : "danger"}>{l.status}</Badge>
                </td>
                <td className="px-3 py-3.5">
                  <div className="flex justify-end gap-1">
                    <IconBtn label="Copy" onClick={() => void copy(l.shortCode)}>
                      <Copy className="size-3.5" />
                    </IconBtn>
                    <IconBtn label="QR code" onClick={() => onQr(l.shortCode)}>
                      <QrCode className="size-3.5" />
                    </IconBtn>
                    <Button asChild size="icon" variant="outline" className="size-8" aria-label="Analytics" title="Analytics">
                      <Link to="/links/$id" params={{ id: l.id }}>
                        <BarChart3 className="size-3.5" />
                      </Link>
                    </Button>
                    <IconBtn
                      label={l.status === "active" ? "Pause" : "Enable"}
                      onClick={() => void toggle(l.id)}
                    >
                      {l.status === "active" ? <Pause className="size-3.5" /> : <Play className="size-3.5" />}
                    </IconBtn>
                    <IconBtn label="Delete" onClick={() => setPendingDelete(l)}>
                      <Trash2 className="size-3.5" />
                    </IconBtn>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {pendingDelete ? shortLabel(pendingDelete.shortCode) : "link"}?</AlertDialogTitle>
            <AlertDialogDescription>Clicks and the short path go with it. This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => void confirmDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function IconBtn({
  children,
  label,
  onClick,
}: {
  children: ReactNode;
  label: string;
  onClick?: () => void;
}) {
  return (
    <Button
      type="button"
      size="icon"
      variant="outline"
      className="size-8"
      aria-label={label}
      title={label}
      onClick={onClick}
    >
      {children}
    </Button>
  );
}
