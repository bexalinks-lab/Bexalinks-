import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { toast } from "sonner";
import { PLANS, type PlanId } from "@/lib/plans";
import { setPlan } from "@/lib/server/profile";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function PricingGrid({ currentPlan }: { currentPlan?: string }) {
  const { user, isPending } = useCurrentUserState();
  const qc = useQueryClient();

  async function choose(planId: PlanId) {
    if (isPending) return;
    if (!user) {
      window.location.href = "/register";
      return;
    }
    try {
      await setPlan({ data: { planId } });
      await qc.invalidateQueries({ queryKey: ["workspace"] });
      toast.success(planId === "free" ? "On the Free plan." : `Moved to ${planId}.`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not update plan");
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {PLANS.map((plan) => {
        const featured = Boolean(plan.featured);
        const active = currentPlan === plan.id;
        return (
          <div
            key={plan.id}
            className={cn(
              "relative flex flex-col rounded-[28px] border bg-card p-7 shadow-[var(--shadow-card)]",
              featured ? "border-primary" : "border-border",
            )}
          >
            {featured ? (
              <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-primary-foreground">
                Most chosen
              </span>
            ) : null}
            <p className="text-sm font-medium text-muted-foreground">{plan.name}</p>
            <p className="mt-3 font-display text-4xl font-semibold tracking-tight">
              {plan.price === 0 ? "Free" : `$${plan.price}`}
              {plan.price > 0 ? (
                <span className="ml-1 text-sm font-medium text-muted-foreground">/mo</span>
              ) : (
                <span className="ml-1 text-sm font-medium text-muted-foreground">forever</span>
              )}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">{plan.blurb}</p>
            <ul className="mt-6 flex flex-1 flex-col gap-2.5 text-sm">
              {plan.features.map((f) => (
                <li key={f} className="flex items-start gap-2">
                  <Check className="mt-0.5 size-4 shrink-0 text-success" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            <Button
              className="mt-8 w-full"
              variant={featured ? "default" : "outline"}
              onClick={() => void choose(plan.id)}
              disabled={active}
            >
              {active ? "Current plan" : plan.price === 0 ? "Start free" : `Choose ${plan.name}`}
            </Button>
            {!user && !isPending ? (
              <p className="mt-3 text-center text-xs text-muted-foreground">
                <Link to="/login" className="underline-offset-2 hover:underline">
                  Log in
                </Link>{" "}
                to apply a plan to your workspace.
              </p>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}
