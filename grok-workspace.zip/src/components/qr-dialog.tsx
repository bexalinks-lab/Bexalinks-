import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { shortHref, shortLabel } from "@/lib/utils";

export function QrDialog({
  code,
  open,
  onOpenChange,
}: {
  code: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    if (!code || !open) return;
    const href = shortHref(code);
    void QRCode.toDataURL(href, {
      width: 360,
      margin: 1,
      color: { dark: "#141312", light: "#fffcf7" },
    }).then(setSrc);
  }, [code, open]);

  if (!code) return null;
  const href = shortHref(code);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="text-center">
        <DialogHeader>
          <DialogTitle>QR for {shortLabel(code)}</DialogTitle>
        </DialogHeader>
        <div className="flex justify-center py-2">
          {src ? (
            <img src={src} alt={`QR code for ${href}`} className="size-[200px] rounded-2xl border border-border" />
          ) : (
            <div className="size-[200px] animate-pulse rounded-2xl bg-muted" />
          )}
        </div>
        <p className="font-mono text-xs text-muted-foreground">{href}</p>
        <div className="mt-2 flex justify-center gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          {src ? (
            <Button asChild>
              <a href={src} download={`linkshort-${code}.png`}>
                Download
              </a>
            </Button>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
}
