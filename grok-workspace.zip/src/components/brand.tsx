import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "grid size-8 place-items-center rounded-[10px] bg-primary text-[13px] font-semibold tracking-tight text-primary-foreground",
        className,
      )}
      aria-hidden
    >
      ln
    </span>
  );
}

export function Logo({ className, tone = "light" }: { className?: string; tone?: "light" | "dark" }) {
  return (
    <Link to="/" className={cn("flex items-center gap-2.5", className)}>
      <Mark className={tone === "dark" ? "bg-ink-foreground text-ink" : undefined} />
      <span
        className={cn(
          "font-display text-[17px] font-semibold tracking-tight",
          tone === "dark" ? "text-ink-foreground" : "text-foreground",
        )}
      >
        LinkShort
      </span>
    </Link>
  );
}
