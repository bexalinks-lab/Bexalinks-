import { Link } from "@tanstack/react-router";
import { Menu } from "lucide-react";
import { useState } from "react";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { Logo } from "./brand";

const NAV = [
  { to: "/pricing" as const, label: "Pricing" },
  { to: "/developers" as const, label: "API" },
  { to: "/admin" as const, label: "Platform" },
];

function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return <Skeleton className="h-9 w-28" />;
  }
  if (user) {
    return (
      <div className="flex items-center gap-3">
        <Button asChild size="sm" variant="outline">
          <Link to="/dashboard">Dashboard</Link>
        </Button>
        <UserButton />
      </div>
    );
  }
  return (
    <div className="flex items-center gap-2">
      <Button asChild size="sm" variant="ghost">
        <Link to="/login">Log in</Link>
      </Button>
      <Button asChild size="sm">
        <Link to="/register">Get started</Link>
      </Button>
    </div>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-[64px] max-w-6xl items-center justify-between px-5">
        <Logo />
        <nav className="hidden items-center gap-8 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="hidden md:block">
          <AuthSlot />
        </div>
        <button
          type="button"
          className="grid size-11 place-items-center rounded-xl border border-border bg-card md:hidden"
          onClick={() => setOpen(true)}
          aria-label="Open menu"
        >
          <Menu className="size-4" />
        </button>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetContent side="right" className="gap-2">
            <Logo />
            <div className="mt-8 flex flex-col gap-1">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="rounded-xl px-3 py-3 text-sm font-medium hover:bg-secondary"
                >
                  {item.label}
                </Link>
              ))}
            </div>
            <div className="mt-6">
              <SignedOut>
                <div className="flex flex-col gap-2">
                  <Button asChild>
                    <Link to="/register" onClick={() => setOpen(false)}>
                      Get started
                    </Link>
                  </Button>
                  <Button asChild variant="outline">
                    <Link to="/login" onClick={() => setOpen(false)}>
                      Log in
                    </Link>
                  </Button>
                </div>
              </SignedOut>
              <SignedIn>
                <Button asChild className="w-full">
                  <Link to="/dashboard" onClick={() => setOpen(false)}>
                    Dashboard
                  </Link>
                </Button>
              </SignedIn>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
