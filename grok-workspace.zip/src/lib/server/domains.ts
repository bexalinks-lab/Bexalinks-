import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { randomId } from "./crypto";
import { ensureProfile, getPlanForUser } from "./profile";
import { planById } from "@/lib/plans";

export type DomainDTO = {
  id: string;
  domain: string;
  status: "pending" | "active";
  createdAt: string;
};

export const listDomains = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string; domain: string; status: string; created_at: string | Date }>`
      select id, domain, status, created_at from domains where user_id = ${context.userId} order by created_at desc
    `;
    return rows.map(
      (r): DomainDTO => ({
        id: r.id,
        domain: r.domain,
        status: r.status === "active" ? "active" : "pending",
        createdAt: r.created_at instanceof Date ? r.created_at.toISOString() : String(r.created_at),
      }),
    );
  });

export const addDomain = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ domain: z.string().trim().min(3).max(120) }))
  .handler(async ({ context, data }) => {
    await ensureProfile(context.userId);
    const plan = planById(await getPlanForUser(context.userId));
    if (plan.limits.domains <= 0) {
      throw new Error("Custom domains require the Pro or Business plan.");
    }
    const domain = data.domain.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(domain)) throw new Error("Enter a valid domain like links.yourbrand.com");
    const sql = await getSql();
    const [{ n }] = await sql<{ n: number }>`select count(*)::int as n from domains where user_id = ${context.userId}`;
    if (Number(n) >= plan.limits.domains) {
      throw new Error(`Your ${plan.name} plan allows ${plan.limits.domains} custom domain${plan.limits.domains === 1 ? "" : "s"}.`);
    }
    const taken = await sql<{ n: number }>`select count(*)::int as n from domains where domain = ${domain}`;
    if (Number(taken[0]?.n) > 0) throw new Error("That domain is already connected.");
    const id = randomId(8);
    await sql`insert into domains (id, user_id, domain, status) values (${id}, ${context.userId}, ${domain}, 'pending')`;
    return { id, domain, status: "pending" as const };
  });

export const verifyDomain = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update domains set status = 'active' where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const removeDomain = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`delete from domains where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });
