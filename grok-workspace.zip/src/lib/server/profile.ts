import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { z } from "zod";
import { planById, type PlanId } from "@/lib/plans";

export async function ensureProfile(userId: string) {
  const sql = await getSql();
  await sql`insert into profiles (user_id, plan) values (${userId}, 'free') on conflict (user_id) do nothing`;
}

export async function getPlanForUser(userId: string): Promise<PlanId> {
  const sql = await getSql();
  await ensureProfile(userId);
  const rows = await sql<{ plan: string }>`select plan from profiles where user_id = ${userId}`;
  const id = rows[0]?.plan ?? "free";
  return (planById(id).id as PlanId);
}

export const getWorkspace = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureProfile(context.userId);
    const [profile] = await sql<{ user_id: string; plan: string; name: string | null }>`
      select user_id, plan, name from profiles where user_id = ${context.userId}
    `;
    const [{ n: linkCount }] = await sql<{ n: number }>`
      select count(*)::int as n from links where user_id = ${context.userId}
    `;
    const [{ n: clickCount }] = await sql<{ n: number }>`
      select count(*)::int as n from clicks c
      join links l on l.id = c.link_id
      where l.user_id = ${context.userId}
    `;
    const [{ n: activeCount }] = await sql<{ n: number }>`
      select count(*)::int as n from links where user_id = ${context.userId} and status = 'active'
    `;
    const [{ n: domainCount }] = await sql<{ n: number }>`
      select count(*)::int as n from domains where user_id = ${context.userId}
    `;
    const plan = planById(profile?.plan ?? "free");
    return {
      planId: plan.id,
      planName: plan.name,
      name: profile?.name ?? "",
      stats: {
        links: Number(linkCount ?? 0),
        clicks: Number(clickCount ?? 0),
        active: Number(activeCount ?? 0),
        domains: Number(domainCount ?? 0),
      },
      limits: plan.limits,
    };
  });

export const saveProfileName = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ name: z.string().trim().max(80) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(context.userId);
    await sql`update profiles set name = ${data.name} where user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const setPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ planId: z.enum(["free", "pro", "business"]) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(context.userId);
    await sql`update profiles set plan = ${data.planId} where user_id = ${context.userId}`;
    return { ok: true as const, planId: data.planId };
  });
