import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  isHttpUrl,
  normalizeAlias,
  parseUserAgent,
  randomId,
  sha256,
  shortCode,
} from "./crypto";
import { ensureProfile, getPlanForUser } from "./profile";
import { planById } from "@/lib/plans";

export type LinkDTO = {
  id: string;
  shortCode: string;
  originalUrl: string;
  hasPassword: boolean;
  status: "active" | "disabled";
  expiresAt: string | null;
  maxClicks: number | null;
  createdAt: string;
  clicks: number;
};

type LinkRow = {
  id: string;
  user_id: string | null;
  short_code: string;
  original_url: string;
  password_hash: string | null;
  status: string;
  expires_at: string | Date | null;
  max_clicks: number | null;
  created_at: string | Date;
  clicks: number | string;
};

function toIso(value: string | Date | null | undefined) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString();
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toISOString();
}

function mapLink(row: LinkRow): LinkDTO {
  return {
    id: row.id,
    shortCode: row.short_code,
    originalUrl: row.original_url,
    hasPassword: Boolean(row.password_hash),
    status: row.status === "disabled" ? "disabled" : "active",
    expiresAt: toIso(row.expires_at),
    maxClicks: row.max_clicks == null ? null : Number(row.max_clicks),
    createdAt: toIso(row.created_at) ?? new Date().toISOString(),
    clicks: Number(row.clicks ?? 0),
  };
}

const createInput = z.object({
  url: z.string().trim().min(4).max(2048),
  alias: z.string().trim().max(32).optional(),
  password: z.string().max(64).optional(),
  expiresAt: z.string().optional(),
  maxClicks: z.number().int().positive().max(1_000_000).optional(),
});

async function allocateCode(desired?: string) {
  const sql = await getSql();
  if (desired) {
    const alias = normalizeAlias(desired);
    if (alias.length < 3) throw new Error("Alias must be at least 3 characters.");
    const taken = await sql<{ n: number }>`select count(*)::int as n from links where short_code = ${alias}`;
    if (Number(taken[0]?.n) > 0) throw new Error("That alias is already taken.");
    return alias;
  }
  for (let i = 0; i < 8; i++) {
    const code = shortCode(7);
    const taken = await sql<{ n: number }>`select count(*)::int as n from links where short_code = ${code}`;
    if (Number(taken[0]?.n) === 0) return code;
  }
  return shortCode(10);
}

async function insertLink(input: z.infer<typeof createInput>, userId: string | null) {
  if (!isHttpUrl(input.url)) throw new Error("Enter a valid URL starting with http:// or https://");
  const sql = await getSql();
  const code = await allocateCode(input.alias);
  const id = randomId(10);
  const passwordHash = input.password?.trim() ? await sha256(input.password.trim()) : null;
  const expires = input.expiresAt?.trim() ? input.expiresAt : null;
  await sql`
    insert into links (id, user_id, short_code, original_url, password_hash, status, expires_at, max_clicks)
    values (
      ${id},
      ${userId},
      ${code},
      ${input.url},
      ${passwordHash},
      'active',
      ${expires},
      ${input.maxClicks ?? null}
    )
  `;
  return { id, shortCode: code, originalUrl: input.url };
}

export const shortenPublic = createServerFn({ method: "POST" })
  .validator(createInput)
  .handler(async ({ data }) => {
    const { getSessionUser } = await import("@/lib/auth/verify.server");
    const user = await getSessionUser();
    return insertLink(data, user?.id ?? null);
  });

export const createLink = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(createInput)
  .handler(async ({ context, data }) => {
    await ensureProfile(context.userId);
    const plan = planById(await getPlanForUser(context.userId));
    const sql = await getSql();
    const [{ n }] = await sql<{ n: number }>`select count(*)::int as n from links where user_id = ${context.userId}`;
    if (Number(n) >= plan.limits.links) {
      throw new Error(`Your ${plan.name} plan allows ${plan.limits.links} links. Upgrade to add more.`);
    }
    return insertLink(data, context.userId);
  });

export const listLinks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ query: z.string().optional() }).optional())
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const q = data?.query?.trim().toLowerCase() ?? "";
    const rows = await sql<LinkRow>`
      select l.id, l.user_id, l.short_code, l.original_url, l.password_hash, l.status,
             l.expires_at, l.max_clicks, l.created_at,
             (select count(*)::int from clicks c where c.link_id = l.id) as clicks
      from links l
      where l.user_id = ${context.userId}
      order by l.created_at desc
    `;
    const mapped = rows.map(mapLink);
    if (!q) return mapped;
    return mapped.filter(
      (l) =>
        l.shortCode.toLowerCase().includes(q) ||
        l.originalUrl.toLowerCase().includes(q),
    );
  });

export const toggleLink = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ status: string }>`
      select status from links where id = ${data.id} and user_id = ${context.userId}
    `;
    if (!rows[0]) throw new Error("Link not found.");
    const next = rows[0].status === "active" ? "disabled" : "active";
    await sql`update links set status = ${next} where id = ${data.id} and user_id = ${context.userId}`;
    return { status: next };
  });

export const deleteLink = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`delete from clicks where link_id = ${data.id}`;
    await sql`delete from links where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

function blockedReason(row: {
  status: string;
  expires_at: string | Date | null;
  max_clicks: number | null;
  clicks: number;
}) {
  if (row.status !== "active") return "This link has been disabled.";
  if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) {
    return "This link has expired.";
  }
  if (row.max_clicks != null && Number(row.clicks) >= Number(row.max_clicks)) {
    return "This link has reached its click limit.";
  }
  return null;
}

export const resolveShortLink = createServerFn({ method: "POST" })
  .validator(z.object({ code: z.string().min(1).max(64), password: z.string().optional() }))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const code = data.code.trim();
    const rows = await sql<LinkRow>`
      select l.id, l.user_id, l.short_code, l.original_url, l.password_hash, l.status,
             l.expires_at, l.max_clicks, l.created_at,
             (select count(*)::int from clicks c where c.link_id = l.id) as clicks
      from links l where l.short_code = ${code}
    `;
    const row = rows[0];
    if (!row) return { kind: "missing" as const };
    const reason = blockedReason({
      status: row.status,
      expires_at: row.expires_at,
      max_clicks: row.max_clicks,
      clicks: Number(row.clicks ?? 0),
    });
    if (reason) return { kind: "blocked" as const, reason };
    if (row.password_hash) {
      if (!data.password) return { kind: "password" as const };
      if ((await sha256(data.password)) !== row.password_hash) {
        return { kind: "bad_password" as const };
      }
    }

    let device = "desktop";
    let browser = "Other";
    let referrer = "";
    try {
      const { getRequest } = await import("@tanstack/react-start/server");
      const req = getRequest();
      const parsed = parseUserAgent(req.headers.get("user-agent") ?? "");
      device = parsed.device;
      browser = parsed.browser;
      referrer = req.headers.get("referer") ?? "";
    } catch {
      /* no request context */
    }

    const clickId = randomId(10);
    await sql`
      insert into clicks (id, link_id, device, browser, referrer)
      values (${clickId}, ${row.id}, ${device}, ${browser}, ${referrer})
    `;
    return { kind: "ok" as const, url: row.original_url };
  });

export const getLinkAnalytics = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const links = await sql<LinkRow>`
      select l.id, l.user_id, l.short_code, l.original_url, l.password_hash, l.status,
             l.expires_at, l.max_clicks, l.created_at,
             (select count(*)::int from clicks c where c.link_id = l.id) as clicks
      from links l
      where l.id = ${data.id} and l.user_id = ${context.userId}
    `;
    const link = links[0];
    if (!link) throw new Error("Link not found.");

    const clickRows = await sql<{
      created_at: string | Date;
      device: string | null;
      browser: string | null;
    }>`
      select created_at, device, browser from clicks where link_id = ${data.id} order by created_at asc
    `;

    const now = Date.now();
    const day = 86400000;
    const series: { day: string; count: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now - i * day);
      const key = d.toISOString().slice(0, 10);
      series.push({ day: key, count: 0 });
    }
    const byDay = new Map(series.map((s) => [s.day, s]));
    const devices: Record<string, number> = {};
    const browsers: Record<string, number> = {};
    let today = 0;
    let week = 0;
    for (const c of clickRows) {
      const ts = new Date(c.created_at).getTime();
      const key = new Date(c.created_at).toISOString().slice(0, 10);
      const bucket = byDay.get(key);
      if (bucket) bucket.count += 1;
      if (now - ts < day) today += 1;
      if (now - ts < 7 * day) week += 1;
      const dvc = c.device || "other";
      const b = c.browser || "Other";
      devices[dvc] = (devices[dvc] ?? 0) + 1;
      browsers[b] = (browsers[b] ?? 0) + 1;
    }

    return {
      link: mapLink(link),
      total: clickRows.length,
      unique: new Set(clickRows.map((c) => `${c.browser}|${c.device}`)).size,
      today,
      week,
      series,
      devices: Object.entries(devices)
        .map(([label, count]) => ({ label, count }))
        .sort((a, b) => b.count - a.count),
      browsers: Object.entries(browsers)
        .map(([label, count]) => ({ label, count }))
        .sort((a, b) => b.count - a.count),
    };
  });
