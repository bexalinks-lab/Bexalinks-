import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { apiSecret, isHttpUrl, normalizeAlias, randomId, sha256, shortCode } from "./crypto";
import { ensureProfile, getPlanForUser } from "./profile";
import { planById } from "@/lib/plans";

export type KeyDTO = {
  id: string;
  prefix: string;
  uses: number;
  createdAt: string;
};

export const listApiKeys = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string; prefix: string; uses: number; created_at: string | Date }>`
      select id, prefix, uses, created_at from api_keys where user_id = ${context.userId} order by created_at desc
    `;
    return rows.map(
      (r): KeyDTO => ({
        id: r.id,
        prefix: r.prefix,
        uses: Number(r.uses ?? 0),
        createdAt: r.created_at instanceof Date ? r.created_at.toISOString() : String(r.created_at),
      }),
    );
  });

export const createApiKey = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureProfile(context.userId);
    const plan = planById(await getPlanForUser(context.userId));
    if (!plan.limits.api) throw new Error("API access requires the Pro or Business plan.");
    const secret = apiSecret();
    const id = randomId(8);
    const prefix = `${secret.slice(0, 12)}…`;
    const sql = await getSql();
    await sql`
      insert into api_keys (id, user_id, key_hash, prefix, uses)
      values (${id}, ${context.userId}, ${await sha256(secret)}, ${prefix}, 0)
    `;
    return { id, prefix, secret };
  });

export const revokeApiKey = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`delete from api_keys where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export async function createLinkWithApiKey(apiKey: string, url: string, alias?: string) {
  if (!isHttpUrl(url)) throw new Error("url must start with http:// or https://");
  const sql = await getSql();
  const hash = await sha256(apiKey);
  const keys = await sql<{ id: string; user_id: string }>`
    select id, user_id from api_keys where key_hash = ${hash}
  `;
  const key = keys[0];
  if (!key) throw new Error("Invalid API key");
  await sql`update api_keys set uses = uses + 1 where id = ${key.id}`;

  let code = alias ? normalizeAlias(alias) : shortCode(7);
  if (alias && code.length < 3) throw new Error("alias must be at least 3 characters");
  const taken = await sql<{ n: number }>`select count(*)::int as n from links where short_code = ${code}`;
  if (Number(taken[0]?.n) > 0) {
    if (alias) throw new Error("alias already taken");
    code = shortCode(10);
  }
  const id = randomId(10);
  await sql`
    insert into links (id, user_id, short_code, original_url, status)
    values (${id}, ${key.user_id}, ${code}, ${url}, 'active')
  `;
  return { shortCode: code };
}
