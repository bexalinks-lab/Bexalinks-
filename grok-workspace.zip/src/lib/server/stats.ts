import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";

export const getPlatformStats = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const [{ links }] = await sql<{ links: number }>`select count(*)::int as links from links`;
  const [{ clicks }] = await sql<{ clicks: number }>`select count(*)::int as clicks from clicks`;
  const [{ workspaces }] = await sql<{ workspaces: number }>`select count(*)::int as workspaces from profiles`;
  const [{ active }] = await sql<{ active: number }>`select count(*)::int as active from links where status = 'active'`;
  return {
    links: Number(links ?? 0),
    clicks: Number(clicks ?? 0),
    workspaces: Number(workspaces ?? 0),
    active: Number(active ?? 0),
  };
});
