import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function shortPath(code: string) {
  return `/s/${code}`;
}

export function shortHref(code: string) {
  if (typeof window === "undefined") return `/s/${code}`;
  return `${window.location.origin}/s/${code}`;
}

export function shortLabel(code: string) {
  if (typeof window === "undefined") return `lnk/${code}`;
  return `${window.location.host}/s/${code}`;
}

export function formatDate(value: string | Date) {
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatNumber(n: number) {
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 }).format(n);
}
