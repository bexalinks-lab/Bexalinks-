-- LinkShort core schema

create table if not exists profiles (
  user_id    text primary key,
  plan       text not null default 'free',
  name       text,
  created_at timestamptz not null default now()
);

create table if not exists links (
  id            text primary key,
  user_id       text,
  short_code    text not null unique,
  original_url  text not null,
  password_hash text,
  status        text not null default 'active',
  expires_at    timestamptz,
  max_clicks    integer,
  created_at    timestamptz not null default now()
);

create index if not exists links_user_id_idx on links (user_id);
create index if not exists links_short_code_idx on links (short_code);

create table if not exists clicks (
  id           text primary key,
  link_id      text not null references links(id) on delete cascade,
  created_at   timestamptz not null default now(),
  device       text,
  browser      text,
  referrer     text
);

create index if not exists clicks_link_id_idx on clicks (link_id);
create index if not exists clicks_created_at_idx on clicks (created_at);

create table if not exists domains (
  id         text primary key,
  user_id    text not null,
  domain     text not null unique,
  status     text not null default 'pending',
  created_at timestamptz not null default now()
);

create index if not exists domains_user_id_idx on domains (user_id);

create table if not exists api_keys (
  id         text primary key,
  user_id    text not null,
  key_hash   text not null unique,
  prefix     text not null,
  uses       integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists api_keys_user_id_idx on api_keys (user_id);
create index if not exists api_keys_hash_idx on api_keys (key_hash);
