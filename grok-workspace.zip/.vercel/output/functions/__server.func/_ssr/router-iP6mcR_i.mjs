import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { F as object, M as literal, P as number, R as string, z as union } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-zKRKBNQv.mjs";
import { n as auth } from "./server-Dvd8xLJE.mjs";
import { t as authMiddleware } from "./middleware-hy77NTFs.mjs";
import { c as shortCode, i as normalizeAlias, n as createSsrRpc, o as randomId, r as isHttpUrl, s as sha256 } from "./createSsrRpc-DqoCRc_G.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { n as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/links-CgeYSC98.js
var createInput = object({
	url: string().trim().min(4).max(2048),
	alias: string().trim().max(32).optional(),
	password: string().max(64).optional(),
	expiresAt: string().optional(),
	maxClicks: number().int().positive().max(1e6).optional()
});
var shortenPublic = createServerFn({ method: "POST" }).validator(createInput).handler(createSsrRpc("8575fd6fca9796a02af42c9c745be668327922df1ea9b11ec310855128c9617b"));
var createLink = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(createInput).handler(createSsrRpc("4ac7b4bb9972cb31ae576382292829abe8025e4615dec78a110cadff9a958596"));
var listLinks = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator(object({ query: string().optional() }).optional()).handler(createSsrRpc("10a200152906c234d8e5911402461c4d5297c5eadd4c31fa49fe879de4c5e749"));
var toggleLink = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(createSsrRpc("f44005aad79dc62c6f3422ceab3b73a890e0cfe42ceb4d70f92fdf2e7e78bdf3"));
var deleteLink = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(createSsrRpc("241f42ff8f7a5023fb3739aafb5b8c7f2f7849ad0656cee5da209d64b4bfa0d5"));
var resolveShortLink = createServerFn({ method: "POST" }).validator(object({
	code: string().min(1).max(64),
	password: string().optional()
})).handler(createSsrRpc("564b17a5258232fed0de348a85650b80b7391b18bbe9156bd1f8ccf84c4bd1a2"));
var getLinkAnalytics = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(createSsrRpc("5e1e26004558890ef1699c377b99e99cb9af15aa6de2ca1c3148dc62deb1e57b"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-iP6mcR_i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function shortHref(code) {
	if (typeof window === "undefined") return `/s/${code}`;
	return `${window.location.origin}/s/${code}`;
}
function shortLabel(code) {
	if (typeof window === "undefined") return `lnk/${code}`;
	return `${window.location.host}/s/${code}`;
}
function formatDate(value) {
	const d = typeof value === "string" ? new Date(value) : value;
	if (Number.isNaN(d.getTime())) return "—";
	return d.toLocaleDateString(void 0, {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
function formatNumber(n) {
	return new Intl.NumberFormat(void 0, { maximumFractionDigits: 0 }).format(n);
}
var TooltipProvider = Provider;
var TooltipContent = (0, import_react.forwardRef)(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 rounded-lg bg-ink px-2 py-1 text-xs text-ink-foreground", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var styles_default = "/assets/styles-BsX838OM.css";
var APP_NAME = "LinkShort";
var Route$20 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Short links with analytics, QR codes, custom domains and a real API."
			},
			{
				name: "theme-color",
				content: "#141312"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Syne:wght@500;600;700;800&display=swap"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	const [queryClient] = (0, import_react.useState)(() => new QueryClient({ defaultOptions: { queries: {
		retry: 1,
		refetchOnWindowFocus: false,
		staleTime: 15e3
	} } }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		className: "antialiased",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-screen bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
					client: queryClient,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, {
						delayDuration: 200,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
							position: "bottom-right",
							toastOptions: { className: "!bg-ink !text-ink-foreground !border-transparent !rounded-xl !font-[Figtree,sans-serif] !text-sm" }
						})]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$17 = () => import("./routes-pUSKX7VL.mjs");
var Route$19 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("../_app-7HENorcf.mjs");
var Route$18 = createFileRoute("/_app")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./admin-CDoDVPMg.mjs");
var Route$17 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./developers-BZT_xXty.mjs");
var Route$16 = createFileRoute("/developers")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./forgot-CHQcQq4C.mjs");
var Route$15 = createFileRoute("/forgot")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./login-BdaXsIGO.mjs");
var Route$14 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./pricing-BK_Kf_x9.mjs");
var Route$13 = createFileRoute("/pricing")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./privacy-B-wE-wNv.mjs");
var Route$12 = createFileRoute("/privacy")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./register-CPCkpxkh.mjs");
var Route$11 = createFileRoute("/register")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./terms-CtU1pqRG.mjs");
var Route$10 = createFileRoute("/terms")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./billing-DtzWYgiL.mjs");
var Route$9 = createFileRoute("/_app/billing")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./dashboard-ThjFy7MP.mjs");
var Route$8 = createFileRoute("/_app/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./domains-DYyFvkU4.mjs");
var Route$7 = createFileRoute("/_app/domains")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./keys-pG81Ypha.mjs");
var Route$6 = createFileRoute("/_app/keys")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./links-suA3H4Xh.mjs");
var Route$5 = createFileRoute("/_app/links")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./settings-D8grz7nG.mjs");
var Route$4 = createFileRoute("/_app/settings")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./s._code-qRBrQE-a.mjs");
var Route$3 = createFileRoute("/s/$code")({
	loader: ({ params }) => resolveShortLink({ data: { code: params.code } }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./links._id-DEO9E-PY.mjs");
var Route$2 = createFileRoute("/_app/links/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var Route$1 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var listApiKeys = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("1fa12f5a751cfbc95d1339462115faffbda6465b0640fe20eed58dd402515e42"));
var createApiKey = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("3cdc4bd28b323b2f3b9e1eefcf9f79f5ff55e983b91e8caa0d2649c3a70b1b3e"));
var revokeApiKey = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(createSsrRpc("fc604686fc92843865a8f06e16f8e3ffac14c0691be0b88fbe74e6c6a073c417"));
async function createLinkWithApiKey(apiKey, url, alias) {
	if (!isHttpUrl(url)) throw new Error("url must start with http:// or https://");
	const sql = await getSql();
	const key = (await sql`
    select id, user_id from api_keys where key_hash = ${await sha256(apiKey)}
  `)[0];
	if (!key) throw new Error("Invalid API key");
	await sql`update api_keys set uses = uses + 1 where id = ${key.id}`;
	let code = alias ? normalizeAlias(alias) : shortCode(7);
	if (alias && code.length < 3) throw new Error("alias must be at least 3 characters");
	const taken = await sql`select count(*)::int as n from links where short_code = ${code}`;
	if (Number(taken[0]?.n) > 0) {
		if (alias) throw new Error("alias already taken");
		code = shortCode(10);
	}
	await sql`
    insert into links (id, user_id, short_code, original_url, status)
    values (${randomId(10)}, ${key.user_id}, ${code}, ${url}, 'active')
  `;
	return { shortCode: code };
}
var Route = createFileRoute("/api/v1/shorten")({ server: { handlers: { POST: async ({ request }) => {
	const token = (request.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
	if (!token) return Response.json({ error: "Missing API key" }, { status: 401 });
	let body = {};
	try {
		body = await request.json();
	} catch {
		return Response.json({ error: "Invalid JSON" }, { status: 400 });
	}
	if (!body.url) return Response.json({ error: "url is required" }, { status: 400 });
	try {
		const result = await createLinkWithApiKey(token, body.url, body.alias);
		const origin = new URL(request.url).origin;
		return Response.json({
			short_url: `${origin}/s/${result.shortCode}`,
			code: result.shortCode
		});
	} catch (e) {
		const msg = e instanceof Error ? e.message : "Failed";
		const status = msg === "Invalid API key" ? 401 : 400;
		return Response.json({ error: msg }, { status });
	}
} } } });
var IndexRoute = Route$19.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$20
});
var AppRoute = Route$18.update({
	id: "/_app",
	getParentRoute: () => Route$20
});
var AdminRoute = Route$17.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$20
});
var DevelopersRoute = Route$16.update({
	id: "/developers",
	path: "/developers",
	getParentRoute: () => Route$20
});
var ForgotRoute = Route$15.update({
	id: "/forgot",
	path: "/forgot",
	getParentRoute: () => Route$20
});
var LoginRoute = Route$14.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$20
});
var PricingRoute = Route$13.update({
	id: "/pricing",
	path: "/pricing",
	getParentRoute: () => Route$20
});
var PrivacyRoute = Route$12.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$20
});
var RegisterRoute = Route$11.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$20
});
var TermsRoute = Route$10.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$20
});
var AppBillingRoute = Route$9.update({
	id: "/billing",
	path: "/billing",
	getParentRoute: () => AppRoute
});
var AppDashboardRoute = Route$8.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AppRoute
});
var AppDomainsRoute = Route$7.update({
	id: "/domains",
	path: "/domains",
	getParentRoute: () => AppRoute
});
var AppKeysRoute = Route$6.update({
	id: "/keys",
	path: "/keys",
	getParentRoute: () => AppRoute
});
var AppLinksRoute = Route$5.update({
	id: "/links",
	path: "/links",
	getParentRoute: () => AppRoute
});
var AppSettingsRoute = Route$4.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AppRoute
});
var SCodeRoute = Route$3.update({
	id: "/s/$code",
	path: "/s/$code",
	getParentRoute: () => Route$20
});
var AppLinksIdRoute = Route$2.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppLinksRoute
});
var ApiAuthSplatRoute = Route$1.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$20
});
var ApiV1ShortenRoute = Route.update({
	id: "/api/v1/shorten",
	path: "/api/v1/shorten",
	getParentRoute: () => Route$20
});
var AppLinksRouteChildren = { AppLinksIdRoute };
var AppRouteChildren = {
	AppBillingRoute,
	AppDashboardRoute,
	AppDomainsRoute,
	AppKeysRoute,
	AppLinksRoute: AppLinksRoute._addFileChildren(AppLinksRouteChildren),
	AppSettingsRoute
};
var rootRouteChildren = {
	IndexRoute,
	AppRoute: AppRoute._addFileChildren(AppRouteChildren),
	AdminRoute,
	DevelopersRoute,
	ForgotRoute,
	LoginRoute,
	PricingRoute,
	PrivacyRoute,
	RegisterRoute,
	TermsRoute,
	SCodeRoute,
	ApiAuthSplatRoute,
	ApiV1ShortenRoute
};
var routeTree = Route$20._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { shortenPublic as _, Route$2 as a, formatDate as c, shortLabel as d, createLink as f, resolveShortLink as g, listLinks as h, revokeApiKey as i, formatNumber as l, getLinkAnalytics as m, createApiKey as n, Route$3 as o, deleteLink as p, listApiKeys as r, cn as s, router_exports as t, shortHref as u, toggleLink as v };
