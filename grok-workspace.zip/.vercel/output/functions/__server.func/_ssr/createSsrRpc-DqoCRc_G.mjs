import { a as getServerFnById, i as TSS_SERVER_FUNCTION } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-DqoCRc_G.js
function toHex(bytes) {
	const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
	return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}
function randomId(bytes = 8) {
	const arr = new Uint8Array(bytes);
	crypto.getRandomValues(arr);
	return toHex(arr);
}
var ALPHABET = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
function shortCode(length = 7) {
	const bytes = new Uint8Array(length);
	crypto.getRandomValues(bytes);
	let out = "";
	for (let i = 0; i < length; i++) out += ALPHABET[bytes[i] % 54];
	return out;
}
function apiSecret() {
	const bytes = /* @__PURE__ */ new Uint8Array(18);
	crypto.getRandomValues(bytes);
	return `sk_live_${btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "")}`;
}
async function sha256(value) {
	const data = new TextEncoder().encode(value);
	return toHex(await crypto.subtle.digest("SHA-256", data));
}
function parseUserAgent(ua) {
	const device = /iPad|Tablet/i.test(ua) ? "tablet" : /Mobi|Android/i.test(ua) ? "mobile" : "desktop";
	let browser = "Other";
	if (/Edg\//i.test(ua)) browser = "Edge";
	else if (/Chrome\//i.test(ua) && !/Edg\//i.test(ua)) browser = "Chrome";
	else if (/Safari\//i.test(ua) && !/Chrome\//i.test(ua)) browser = "Safari";
	else if (/Firefox\//i.test(ua)) browser = "Firefox";
	return {
		device,
		browser
	};
}
function isHttpUrl(value) {
	try {
		const u = new URL(value);
		return u.protocol === "http:" || u.protocol === "https:";
	} catch {
		return false;
	}
}
function normalizeAlias(alias) {
	return alias.trim().toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
export { parseUserAgent as a, shortCode as c, normalizeAlias as i, createSsrRpc as n, randomId as o, isHttpUrl as r, sha256 as s, apiSecret as t };
