//#region node_modules/.nitro/vite/services/ssr/assets/plans-BcK06FWz.js
var PLANS = [
	{
		id: "free",
		name: "Free",
		price: 0,
		blurb: "For trying the craft.",
		features: [
			"50 links / month",
			"Basic click counts",
			"QR codes",
			"Public short links"
		],
		limits: {
			links: 50,
			domains: 0,
			api: false
		}
	},
	{
		id: "pro",
		name: "Pro",
		price: 12,
		blurb: "For teams that ship links weekly.",
		featured: true,
		features: [
			"5,000 links / month",
			"Device & browser analytics",
			"1 custom domain",
			"API access",
			"Password, expiry, click caps"
		],
		limits: {
			links: 5e3,
			domains: 1,
			api: true
		}
	},
	{
		id: "business",
		name: "Business",
		price: 39,
		blurb: "For brands that own the click.",
		features: [
			"100,000 links / month",
			"Multiple custom domains",
			"Full API + bulk create",
			"Priority routing",
			"Workspace controls"
		],
		limits: {
			links: 1e5,
			domains: 20,
			api: true
		}
	}
];
function planById(id) {
	return PLANS.find((p) => p.id === id) ?? PLANS[0];
}
//#endregion
export { planById as n, PLANS as t };
