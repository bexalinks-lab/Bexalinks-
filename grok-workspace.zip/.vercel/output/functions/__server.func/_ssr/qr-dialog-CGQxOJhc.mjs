import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime, a as Overlay2, c as Title2, d as DialogContent$1, f as DialogDescription$1, h as DialogTitle$1, i as Description2, l as Dialog$1, m as DialogPortal$1, n as Cancel, o as Portal2, p as DialogOverlay$1, r as Content2, s as Root2, t as Action, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { l as Play, r as Trash2, s as QrCode, t as X, u as Pause, x as ChartColumn, y as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as formatDate, d as shortLabel, f as createLink, l as formatNumber, p as deleteLink, s as cn, u as shortHref, v as toggleLink } from "./router-iP6mcR_i.mjs";
import { n as buttonVariants, t as Button } from "./button-BKFq4Z1C.mjs";
import { t as Input } from "./input-CLVrXCRj.mjs";
import { t as Label } from "./label-CDr0-t28.mjs";
import { t as Badge } from "./badge-DQZDnHgg.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qr-dialog-CGQxOJhc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/40", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = (0, import_react.forwardRef)(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 w-[min(440px,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-border bg-card p-6 shadow-[var(--shadow-card)]", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-5 space-y-1.5 pr-6", className),
		...props
	});
}
var DialogTitle = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-xl font-semibold", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function CreateLinkDialog({ open, onOpenChange, onCreated }) {
	const [url, setUrl] = (0, import_react.useState)("");
	const [alias, setAlias] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [expiresAt, setExpiresAt] = (0, import_react.useState)("");
	const [maxClicks, setMaxClicks] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	function reset() {
		setUrl("");
		setAlias("");
		setPassword("");
		setExpiresAt("");
		setMaxClicks("");
	}
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			const created = await createLink({ data: {
				url: url.trim(),
				alias: alias.trim() || void 0,
				password: password.trim() || void 0,
				expiresAt: expiresAt || void 0,
				maxClicks: maxClicks ? Number(maxClicks) : void 0
			} });
			toast.success(`Created /s/${created.shortCode}`);
			reset();
			onOpenChange(false);
			onCreated?.();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not create link");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New short link" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Point a short path at any public URL. Optional gates keep it quiet." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "dest",
					children: "Destination URL"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "dest",
					value: url,
					onChange: (e) => setUrl(e.target.value),
					placeholder: "https://example.com/article",
					required: true
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "alias",
					children: "Custom alias"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "alias",
					value: alias,
					onChange: (e) => setAlias(e.target.value),
					placeholder: "launch-week"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "pw",
					children: "Password"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "pw",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					placeholder: "Leave blank for open access"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "exp",
						children: "Expires"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "exp",
						type: "date",
						value: expiresAt,
						onChange: (e) => setExpiresAt(e.target.value)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "cap",
						children: "Click cap"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "cap",
						inputMode: "numeric",
						value: maxClicks,
						onChange: (e) => setMaxClicks(e.target.value),
						placeholder: "Unlimited"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						children: busy ? "Creating…" : "Create link"
					})]
				})
			]
		})] })
	});
}
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/40", className),
	...props
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 w-[min(400px,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-border bg-card p-6 shadow-[var(--shadow-card)]", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("space-y-1.5", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-6 flex justify-end gap-2", className),
		...props
	});
}
var AlertDialogTitle = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("font-display text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
function LinksTable({ links, dense, onChange, onQr }) {
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	async function copy(code) {
		try {
			await navigator.clipboard.writeText(shortHref(code));
			toast.success("Copied");
		} catch {
			toast.error("Could not copy");
		}
	}
	async function toggle(id) {
		try {
			const res = await toggleLink({ data: { id } });
			toast.success(res.status === "active" ? "Link enabled" : "Link paused");
			onChange();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not update");
		}
	}
	async function confirmDelete() {
		if (!pendingDelete) return;
		try {
			await deleteLink({ data: { id: pendingDelete.id } });
			toast.success("Link deleted");
			setPendingDelete(null);
			onChange();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not delete");
		}
	}
	if (!links.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg",
			children: "No links yet"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Create one and it will land here, with click counts attached."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[640px] text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-5 pb-3 pt-4 font-semibold",
						children: "Short link"
					}),
					!dense ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 pb-3 pt-4 font-semibold",
						children: "Destination"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 pb-3 pt-4 font-semibold",
						children: "Clicks"
					}),
					!dense ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 pb-3 pt-4 font-semibold",
						children: "Created"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 pb-3 pt-4 font-semibold",
						children: "Status"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 pb-3 pt-4 font-semibold" })
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border/80 hover:bg-muted/40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-5 py-3.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: shortHref(l.shortCode),
							target: "_blank",
							rel: "noreferrer",
							className: "font-mono text-[13px] font-semibold text-primary hover:underline",
							children: shortLabel(l.shortCode)
						})
					}),
					!dense ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "max-w-[240px] truncate px-3 py-3.5 text-muted-foreground",
						children: l.originalUrl
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-3.5 tabular-nums",
						children: formatNumber(l.clicks)
					}),
					!dense ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-3.5 text-muted-foreground",
						children: formatDate(l.createdAt)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-3.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: l.status === "active" ? "success" : "danger",
							children: l.status
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-3.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: "Copy",
									onClick: () => void copy(l.shortCode),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: "QR code",
									onClick: () => onQr(l.shortCode),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-3.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "icon",
									variant: "outline",
									className: "size-8",
									"aria-label": "Analytics",
									title: "Analytics",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/links/$id",
										params: { id: l.id },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-3.5" })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: l.status === "active" ? "Pause" : "Enable",
									onClick: () => void toggle(l.id),
									children: l.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: "Delete",
									onClick: () => setPendingDelete(l),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})
							]
						})
					})
				]
			}, l.id)) })]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: !!pendingDelete,
		onOpenChange: (o) => !o && setPendingDelete(null),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, { children: [
			"Delete ",
			pendingDelete ? shortLabel(pendingDelete.shortCode) : "link",
			"?"
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "Clicks and the short path go with it. This cannot be undone." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
			onClick: () => void confirmDelete(),
			children: "Delete"
		})] })] })
	})] });
}
function IconBtn({ children, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		size: "icon",
		variant: "outline",
		className: "size-8",
		"aria-label": label,
		title: label,
		onClick,
		children
	});
}
function QrDialog({ code, open, onOpenChange }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!code || !open) return;
		const href = shortHref(code);
		import_lib.toDataURL(href, {
			width: 360,
			margin: 1,
			color: {
				dark: "#141312",
				light: "#fffcf7"
			}
		}).then(setSrc);
	}, [code, open]);
	if (!code) return null;
	const href = shortHref(code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["QR for ", shortLabel(code)] }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center py-2",
					children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: `QR code for ${href}`,
						className: "size-[200px] rounded-2xl border border-border"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-[200px] animate-pulse rounded-2xl bg-muted" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-muted-foreground",
					children: href
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => onOpenChange(false),
						children: "Close"
					}), src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: src,
							download: `linkshort-${code}.png`,
							children: "Download"
						})
					}) : null]
				})
			]
		})
	});
}
//#endregion
export { LinksTable as n, QrDialog as r, CreateLinkDialog as t };
