import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { S as ArrowRight, _ as Earth, a as ShieldCheck, b as Check, f as Lock, h as KeyRound, i as Timer, s as QrCode, w as Activity, y as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as shortenPublic, d as shortLabel, f as createLink, u as shortHref } from "./router-iP6mcR_i.mjs";
import { n as useCurrentUserState } from "./use-current-user-DG6UNzh9.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-D7C9LyJs.mjs";
import { t as PricingGrid } from "./pricing-grid-B452kHFo.mjs";
import { t as Input } from "./input-CLVrXCRj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-pUSKX7VL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShortenerBox() {
	const { user, isPending } = useCurrentUserState();
	const [url, setUrl] = (0, import_react.useState)("");
	const [alias, setAlias] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function onSubmit(e) {
		e.preventDefault();
		if (!url.trim()) {
			toast.error("Paste a URL first.");
			return;
		}
		setBusy(true);
		try {
			const payload = {
				url: url.trim(),
				alias: alias.trim() || void 0
			};
			const created = user && !isPending ? await createLink({ data: payload }) : await shortenPublic({ data: payload });
			setResult({
				code: created.shortCode,
				original: created.originalUrl
			});
			setUrl("");
			setAlias("");
			toast.success(user ? "Link added to your workspace." : "Short link ready.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not shorten that URL");
		} finally {
			setBusy(false);
		}
	}
	async function copy() {
		if (!result) return;
		const href = shortHref(result.code);
		try {
			await navigator.clipboard.writeText(href);
			setCopied(true);
			toast.success("Copied to clipboard");
			setTimeout(() => setCopied(false), 1600);
		} catch {
			toast.error("Could not copy");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[28px] border border-border bg-card p-4 shadow-[var(--shadow-card)] sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: url,
					onChange: (e) => setUrl(e.target.value),
					placeholder: "Paste a long URL — https://…",
					className: "h-12 flex-1 rounded-2xl px-4",
					inputMode: "url",
					autoComplete: "off"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					size: "lg",
					className: "h-12 rounded-2xl sm:w-auto",
					disabled: busy,
					children: [busy ? "Shortening…" : "Shorten", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 font-mono text-xs",
					children: "alias"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: alias,
					onChange: (e) => setAlias(e.target.value),
					placeholder: "custom-slug (optional)",
					className: "h-10 rounded-xl font-mono text-sm"
				})]
			})]
		}), result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col gap-3 rounded-2xl border border-primary/30 bg-primary/5 px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-mono text-sm font-semibold text-primary",
					children: shortLabel(result.code)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted-foreground",
					children: result.original
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "sm",
				variant: "secondary",
				onClick: () => void copy(),
				children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "Copied" : "Copy"]
			})]
		}) : null]
	});
}
var FEATURES = [
	{
		icon: Earth,
		title: "Custom domains",
		body: "Serve short paths on links.yourbrand.com. Keep the destination yours."
	},
	{
		icon: Activity,
		title: "Click analytics",
		body: "Device, browser and a fourteen-day pulse the moment someone lands."
	},
	{
		icon: Lock,
		title: "Password gates",
		body: "Hold a sensitive redirect behind a passphrase before it fires."
	},
	{
		icon: Timer,
		title: "Expiry & caps",
		body: "Kill a link on a date, or after a fixed number of clicks."
	},
	{
		icon: KeyRound,
		title: "Developer API",
		body: "Mint keys in the dashboard and shorten from your own code."
	},
	{
		icon: ShieldCheck,
		title: "Quiet by default",
		body: "No cluttered dashboards. One workspace, one accent, real numbers."
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-6xl px-5 pb-16 pt-14 sm:pt-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stagger-in max-w-3xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-5 inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-primary",
									children: "Short links, set in type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "font-display text-5xl font-semibold tracking-tight sm:text-6xl lg:text-[72px]",
									children: [
										"Cut the URL.",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Keep the story."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-xl text-lg text-muted-foreground",
									children: "LinkShort turns long destinations into branded paths — then shows who clicked, from where, and on what. Built for people who ship links as often as they ship code."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 max-w-2xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortenerBox, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-14 grid grid-cols-2 gap-3 sm:grid-cols-4",
							children: [
								["Fast redirects", "No interstitial junk"],
								["Custom aliases", "Names you can remember"],
								["QR in one tap", "Print-ready marks"],
								["Real API", "Bearer keys, JSON in"]
							].map(([t, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border bg-card px-4 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: t
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: s
								})]
							}, t))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hairline mx-auto max-w-6xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "features",
					className: "mx-auto max-w-6xl px-5 py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-semibold sm:text-4xl",
							children: "Everything a growing team needs from a link"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-muted-foreground",
							children: "Not just a redirect — a small piece of infrastructure for every URL you share."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: FEATURES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-4 grid size-10 place-items-center rounded-xl bg-secondary text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg font-semibold",
									children: f.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground",
									children: f.body
								})
							]
						}, f.title))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-ink text-ink-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl items-center gap-10 px-5 py-20 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-[0.16em] text-haze",
								children: "Analytics"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-3xl font-semibold sm:text-4xl",
								children: "See the click, not just the count"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-md text-sm leading-relaxed text-haze",
								children: "Every short path records device, browser and a daily pulse. Open a link in your workspace and the last fourteen days draw themselves."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "invert",
								className: "mt-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/register",
									children: ["Start a workspace", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-[28px] border border-white/10 bg-white/5 p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-end justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: "Clicks · 14 days"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-4 text-haze" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 flex h-36 items-end gap-1.5",
									children: [
										22,
										34,
										28,
										51,
										40,
										63,
										48,
										72,
										58,
										80,
										66,
										90,
										74,
										88
									].map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex-1 rounded-t-sm bg-ink-foreground/80",
										style: { height: `${h}%` }
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 grid grid-cols-3 gap-3 text-xs",
									children: [
										["Desktop", "62%"],
										["Mobile", "31%"],
										["Tablet", "7%"]
									].map(([l, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-white/5 px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-haze",
											children: l
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 font-semibold tabular-nums",
											children: v
										})]
									}, l))
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-6xl px-5 py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-xl text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-semibold sm:text-4xl",
							children: "Simple pricing, no theatre"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-muted-foreground",
							children: "Start free. Upgrade when you need a domain or the API."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PricingGrid, {})
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
