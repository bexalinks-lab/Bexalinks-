import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { s as cn } from "./router-iP6mcR_i.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/label-CDr0-t28.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Label = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
	ref,
	className: cn("mb-1.5 block text-sm font-medium text-foreground", className),
	...props
}));
Label.displayName = "Label";
//#endregion
export { Label as t };
