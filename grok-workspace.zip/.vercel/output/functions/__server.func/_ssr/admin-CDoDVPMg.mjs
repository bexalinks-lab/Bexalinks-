import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { n as createSsrRpc } from "./createSsrRpc-DqoCRc_G.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { l as formatNumber } from "./router-iP6mcR_i.mjs";
import { t as Skeleton } from "./skeleton-DFlRoMjn.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-D7C9LyJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CDoDVPMg.js
var import_jsx_runtime = require_jsx_runtime();
var getPlatformStats = createServerFn({ method: "GET" }).handler(createSsrRpc("db9ccbc68c738f3dead78d6712e6b27424b1b0a201e02ce14f20ff4c518fdec4"));
function AdminPage() {
	const stats = useQuery({
		queryKey: ["platform"],
		queryFn: () => getPlatformStats()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.16em] text-primary",
						children: "Platform"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl font-semibold",
						children: "A quiet ledger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-muted-foreground",
						children: "Aggregate counts across this instance. Individual accounts stay private — no emails, no suspend switches, no other people's links."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
						children: stats.isPending ? Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28 rounded-3xl" }, i)) : [
							["Links minted", stats.data?.links ?? 0],
							["Clicks recorded", stats.data?.clicks ?? 0],
							["Active paths", stats.data?.active ?? 0],
							["Workspaces", stats.data?.workspaces ?? 0]
						].map(([label, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl font-semibold tabular-nums",
								children: formatNumber(Number(n))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: label
							})]
						}, String(label)))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { AdminPage as component };
