import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { g as resolveShortLink, o as Route$3 } from "./router-iP6mcR_i.mjs";
import { t as Logo } from "./brand-Dh2jgtgc.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { t as Input } from "./input-CLVrXCRj.mjs";
import { t as Label } from "./label-CDr0-t28.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/s._code-qRBrQE-a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShortLinkPage() {
	const data = Route$3.useLoaderData();
	const { code } = Route$3.useParams();
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [url, setUrl] = (0, import_react.useState)(data.kind === "ok" ? data.url : null);
	(0, import_react.useEffect)(() => {
		if (url) window.location.replace(url);
	}, [url]);
	async function unlock(e) {
		e.preventDefault();
		setBusy(true);
		setError("");
		try {
			const res = await resolveShortLink({ data: {
				code,
				password
			} });
			if (res.kind === "ok") setUrl(res.url);
			else if (res.kind === "bad_password") setError("That password does not match.");
			else if (res.kind === "blocked") setError(res.reason);
			else setError("This link is not available.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not open link");
		} finally {
			setBusy(false);
		}
	}
	if (url) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold",
			children: "Redirecting"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Taking you to the destination."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: url,
			className: "mt-6 inline-block text-sm font-semibold text-primary hover:underline",
			children: "Continue"
		})
	] });
	if (data.kind === "missing") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold",
			children: "No such link"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "This short path is not in the ledger."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Make a new one"
			})
		})
	] });
	if (data.kind === "blocked") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold",
			children: "Link unavailable"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: data.reason
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "outline",
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Home"
			})
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold",
			children: "Protected link"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Enter the password to continue to the destination."
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-destructive",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: unlock,
			className: "mt-6 space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "pw",
				children: "Password"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "pw",
				type: "password",
				value: password,
				onChange: (e) => setPassword(e.target.value),
				autoFocus: true
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "w-full",
				disabled: busy,
				children: busy ? "Checking…" : "Continue"
			})]
		})
	] });
}
function GateShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 rounded-[28px] border border-border bg-card p-8 shadow-[var(--shadow-card)]",
				children
			})]
		})
	});
}
//#endregion
export { ShortLinkPage as component };
