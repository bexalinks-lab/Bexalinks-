import { r as createServerFn } from "./ssr.mjs";
import { F as object, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-zKRKBNQv.mjs";
import { t as authMiddleware } from "./middleware-hy77NTFs.mjs";
import { o as randomId } from "./createSsrRpc-DqoCRc_G.mjs";
import { n as planById } from "./plans-BcK06FWz.mjs";
import { n as getPlanForUser, t as ensureProfile } from "./profile-BmeAM3-D.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/domains-DU2-Fmnl.js
var listDomains_createServerFn_handler = createServerRpc({
	id: "eb3bae0a0ae595dd95004bcb493dadf924da9cac50781f6cce27900429b364de",
	name: "listDomains",
	filename: "src/lib/server/domains.ts"
}, (opts) => listDomains.__executeServer(opts));
var listDomains = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listDomains_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select id, domain, status, created_at from domains where user_id = ${context.userId} order by created_at desc
    `).map((r) => ({
		id: r.id,
		domain: r.domain,
		status: r.status === "active" ? "active" : "pending",
		createdAt: r.created_at instanceof Date ? r.created_at.toISOString() : String(r.created_at)
	}));
});
var addDomain_createServerFn_handler = createServerRpc({
	id: "739edf1db12ac2ce3a4be56a5cbbe41cd481d6a33714556d277c184c60af1cc8",
	name: "addDomain",
	filename: "src/lib/server/domains.ts"
}, (opts) => addDomain.__executeServer(opts));
var addDomain = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ domain: string().trim().min(3).max(120) })).handler(addDomain_createServerFn_handler, async ({ context, data }) => {
	await ensureProfile(context.userId);
	const plan = planById(await getPlanForUser(context.userId));
	if (plan.limits.domains <= 0) throw new Error("Custom domains require the Pro or Business plan.");
	const domain = data.domain.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
	if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(domain)) throw new Error("Enter a valid domain like links.yourbrand.com");
	const sql = await getSql();
	const [{ n }] = await sql`select count(*)::int as n from domains where user_id = ${context.userId}`;
	if (Number(n) >= plan.limits.domains) throw new Error(`Your ${plan.name} plan allows ${plan.limits.domains} custom domain${plan.limits.domains === 1 ? "" : "s"}.`);
	const taken = await sql`select count(*)::int as n from domains where domain = ${domain}`;
	if (Number(taken[0]?.n) > 0) throw new Error("That domain is already connected.");
	const id = randomId(8);
	await sql`insert into domains (id, user_id, domain, status) values (${id}, ${context.userId}, ${domain}, 'pending')`;
	return {
		id,
		domain,
		status: "pending"
	};
});
var verifyDomain_createServerFn_handler = createServerRpc({
	id: "ee4f46ed20fccadb23c5931b3b592df79f98a079f94b33ac3f4e03e10c1299e3",
	name: "verifyDomain",
	filename: "src/lib/server/domains.ts"
}, (opts) => verifyDomain.__executeServer(opts));
var verifyDomain = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(verifyDomain_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`update domains set status = 'active' where id = ${data.id} and user_id = ${context.userId}`;
	return { ok: true };
});
var removeDomain_createServerFn_handler = createServerRpc({
	id: "7a36ef2f7b05f2fc25e16dab4231dda0c7f58fc4f52e48b5060c5b67d9058468",
	name: "removeDomain",
	filename: "src/lib/server/domains.ts"
}, (opts) => removeDomain.__executeServer(opts));
var removeDomain = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(removeDomain_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`delete from domains where id = ${data.id} and user_id = ${context.userId}`;
	return { ok: true };
});
//#endregion
export { addDomain_createServerFn_handler, listDomains_createServerFn_handler, removeDomain_createServerFn_handler, verifyDomain_createServerFn_handler };
