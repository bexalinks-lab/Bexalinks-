import { r as createServerFn } from "./ssr.mjs";
import { D as _enum, F as object, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-zKRKBNQv.mjs";
import { t as authMiddleware } from "./middleware-hy77NTFs.mjs";
import { n as planById } from "./plans-BcK06FWz.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-DEAM8Q7u.js
async function ensureProfile(userId) {
	await (await getSql())`insert into profiles (user_id, plan) values (${userId}, 'free') on conflict (user_id) do nothing`;
}
var getWorkspace_createServerFn_handler = createServerRpc({
	id: "bbc1c4ac15d24002410ca4e216d0bd6701f196f5125f7218f06d0016e85354a7",
	name: "getWorkspace",
	filename: "src/lib/server/profile.ts"
}, (opts) => getWorkspace.__executeServer(opts));
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getWorkspace_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureProfile(context.userId);
	const [profile] = await sql`
      select user_id, plan, name from profiles where user_id = ${context.userId}
    `;
	const [{ n: linkCount }] = await sql`
      select count(*)::int as n from links where user_id = ${context.userId}
    `;
	const [{ n: clickCount }] = await sql`
      select count(*)::int as n from clicks c
      join links l on l.id = c.link_id
      where l.user_id = ${context.userId}
    `;
	const [{ n: activeCount }] = await sql`
      select count(*)::int as n from links where user_id = ${context.userId} and status = 'active'
    `;
	const [{ n: domainCount }] = await sql`
      select count(*)::int as n from domains where user_id = ${context.userId}
    `;
	const plan = planById(profile?.plan ?? "free");
	return {
		planId: plan.id,
		planName: plan.name,
		name: profile?.name ?? "",
		stats: {
			links: Number(linkCount ?? 0),
			clicks: Number(clickCount ?? 0),
			active: Number(activeCount ?? 0),
			domains: Number(domainCount ?? 0)
		},
		limits: plan.limits
	};
});
var saveProfileName_createServerFn_handler = createServerRpc({
	id: "e8511bf8658539521ddfda03991ba20f4091a7e84753529a476cf20cb77a5e82",
	name: "saveProfileName",
	filename: "src/lib/server/profile.ts"
}, (opts) => saveProfileName.__executeServer(opts));
var saveProfileName = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ name: string().trim().max(80) })).handler(saveProfileName_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(context.userId);
	await sql`update profiles set name = ${data.name} where user_id = ${context.userId}`;
	return { ok: true };
});
var setPlan_createServerFn_handler = createServerRpc({
	id: "66f53ade48d619ceecc4cdf934e61b110ca3ddae6c656ed2d8efb8c8a3860cff",
	name: "setPlan",
	filename: "src/lib/server/profile.ts"
}, (opts) => setPlan.__executeServer(opts));
var setPlan = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ planId: _enum([
	"free",
	"pro",
	"business"
]) })).handler(setPlan_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(context.userId);
	await sql`update profiles set plan = ${data.planId} where user_id = ${context.userId}`;
	return {
		ok: true,
		planId: data.planId
	};
});
//#endregion
export { getWorkspace_createServerFn_handler, saveProfileName_createServerFn_handler, setPlan_createServerFn_handler };
