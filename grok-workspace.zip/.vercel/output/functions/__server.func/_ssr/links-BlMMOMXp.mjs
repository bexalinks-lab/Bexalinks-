import { r as createServerFn } from "./ssr.mjs";
import { F as object, P as number, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-zKRKBNQv.mjs";
import { t as authMiddleware } from "./middleware-hy77NTFs.mjs";
import { a as parseUserAgent, c as shortCode, i as normalizeAlias, o as randomId, r as isHttpUrl, s as sha256 } from "./createSsrRpc-DqoCRc_G.mjs";
import { n as planById } from "./plans-BcK06FWz.mjs";
import { n as getPlanForUser, t as ensureProfile } from "./profile-BmeAM3-D.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/links-BlMMOMXp.js
function toIso(value) {
	if (!value) return null;
	if (value instanceof Date) return value.toISOString();
	const d = new Date(value);
	return Number.isNaN(d.getTime()) ? String(value) : d.toISOString();
}
function mapLink(row) {
	return {
		id: row.id,
		shortCode: row.short_code,
		originalUrl: row.original_url,
		hasPassword: Boolean(row.password_hash),
		status: row.status === "disabled" ? "disabled" : "active",
		expiresAt: toIso(row.expires_at),
		maxClicks: row.max_clicks == null ? null : Number(row.max_clicks),
		createdAt: toIso(row.created_at) ?? (/* @__PURE__ */ new Date()).toISOString(),
		clicks: Number(row.clicks ?? 0)
	};
}
var createInput = object({
	url: string().trim().min(4).max(2048),
	alias: string().trim().max(32).optional(),
	password: string().max(64).optional(),
	expiresAt: string().optional(),
	maxClicks: number().int().positive().max(1e6).optional()
});
async function allocateCode(desired) {
	const sql = await getSql();
	if (desired) {
		const alias = normalizeAlias(desired);
		if (alias.length < 3) throw new Error("Alias must be at least 3 characters.");
		const taken = await sql`select count(*)::int as n from links where short_code = ${alias}`;
		if (Number(taken[0]?.n) > 0) throw new Error("That alias is already taken.");
		return alias;
	}
	for (let i = 0; i < 8; i++) {
		const code = shortCode(7);
		const taken = await sql`select count(*)::int as n from links where short_code = ${code}`;
		if (Number(taken[0]?.n) === 0) return code;
	}
	return shortCode(10);
}
async function insertLink(input, userId) {
	if (!isHttpUrl(input.url)) throw new Error("Enter a valid URL starting with http:// or https://");
	const sql = await getSql();
	const code = await allocateCode(input.alias);
	const id = randomId(10);
	const passwordHash = input.password?.trim() ? await sha256(input.password.trim()) : null;
	const expires = input.expiresAt?.trim() ? input.expiresAt : null;
	await sql`
    insert into links (id, user_id, short_code, original_url, password_hash, status, expires_at, max_clicks)
    values (
      ${id},
      ${userId},
      ${code},
      ${input.url},
      ${passwordHash},
      'active',
      ${expires},
      ${input.maxClicks ?? null}
    )
  `;
	return {
		id,
		shortCode: code,
		originalUrl: input.url
	};
}
var shortenPublic_createServerFn_handler = createServerRpc({
	id: "8575fd6fca9796a02af42c9c745be668327922df1ea9b11ec310855128c9617b",
	name: "shortenPublic",
	filename: "src/lib/server/links.ts"
}, (opts) => shortenPublic.__executeServer(opts));
var shortenPublic = createServerFn({ method: "POST" }).validator(createInput).handler(shortenPublic_createServerFn_handler, async ({ data }) => {
	const { getSessionUser } = await import("./verify.server-Dl2BzB2M.mjs");
	return insertLink(data, (await getSessionUser())?.id ?? null);
});
var createLink_createServerFn_handler = createServerRpc({
	id: "4ac7b4bb9972cb31ae576382292829abe8025e4615dec78a110cadff9a958596",
	name: "createLink",
	filename: "src/lib/server/links.ts"
}, (opts) => createLink.__executeServer(opts));
var createLink = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(createInput).handler(createLink_createServerFn_handler, async ({ context, data }) => {
	await ensureProfile(context.userId);
	const plan = planById(await getPlanForUser(context.userId));
	const [{ n }] = await (await getSql())`select count(*)::int as n from links where user_id = ${context.userId}`;
	if (Number(n) >= plan.limits.links) throw new Error(`Your ${plan.name} plan allows ${plan.limits.links} links. Upgrade to add more.`);
	return insertLink(data, context.userId);
});
var listLinks_createServerFn_handler = createServerRpc({
	id: "10a200152906c234d8e5911402461c4d5297c5eadd4c31fa49fe879de4c5e749",
	name: "listLinks",
	filename: "src/lib/server/links.ts"
}, (opts) => listLinks.__executeServer(opts));
var listLinks = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator(object({ query: string().optional() }).optional()).handler(listLinks_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const q = data?.query?.trim().toLowerCase() ?? "";
	const mapped = (await sql`
      select l.id, l.user_id, l.short_code, l.original_url, l.password_hash, l.status,
             l.expires_at, l.max_clicks, l.created_at,
             (select count(*)::int from clicks c where c.link_id = l.id) as clicks
      from links l
      where l.user_id = ${context.userId}
      order by l.created_at desc
    `).map(mapLink);
	if (!q) return mapped;
	return mapped.filter((l) => l.shortCode.toLowerCase().includes(q) || l.originalUrl.toLowerCase().includes(q));
});
var toggleLink_createServerFn_handler = createServerRpc({
	id: "f44005aad79dc62c6f3422ceab3b73a890e0cfe42ceb4d70f92fdf2e7e78bdf3",
	name: "toggleLink",
	filename: "src/lib/server/links.ts"
}, (opts) => toggleLink.__executeServer(opts));
var toggleLink = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(toggleLink_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const rows = await sql`
      select status from links where id = ${data.id} and user_id = ${context.userId}
    `;
	if (!rows[0]) throw new Error("Link not found.");
	const next = rows[0].status === "active" ? "disabled" : "active";
	await sql`update links set status = ${next} where id = ${data.id} and user_id = ${context.userId}`;
	return { status: next };
});
var deleteLink_createServerFn_handler = createServerRpc({
	id: "241f42ff8f7a5023fb3739aafb5b8c7f2f7849ad0656cee5da209d64b4bfa0d5",
	name: "deleteLink",
	filename: "src/lib/server/links.ts"
}, (opts) => deleteLink.__executeServer(opts));
var deleteLink = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(deleteLink_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await sql`delete from clicks where link_id = ${data.id}`;
	await sql`delete from links where id = ${data.id} and user_id = ${context.userId}`;
	return { ok: true };
});
function blockedReason(row) {
	if (row.status !== "active") return "This link has been disabled.";
	if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) return "This link has expired.";
	if (row.max_clicks != null && Number(row.clicks) >= Number(row.max_clicks)) return "This link has reached its click limit.";
	return null;
}
var resolveShortLink_createServerFn_handler = createServerRpc({
	id: "564b17a5258232fed0de348a85650b80b7391b18bbe9156bd1f8ccf84c4bd1a2",
	name: "resolveShortLink",
	filename: "src/lib/server/links.ts"
}, (opts) => resolveShortLink.__executeServer(opts));
var resolveShortLink = createServerFn({ method: "POST" }).validator(object({
	code: string().min(1).max(64),
	password: string().optional()
})).handler(resolveShortLink_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const row = (await sql`
      select l.id, l.user_id, l.short_code, l.original_url, l.password_hash, l.status,
             l.expires_at, l.max_clicks, l.created_at,
             (select count(*)::int from clicks c where c.link_id = l.id) as clicks
      from links l where l.short_code = ${data.code.trim()}
    `)[0];
	if (!row) return { kind: "missing" };
	const reason = blockedReason({
		status: row.status,
		expires_at: row.expires_at,
		max_clicks: row.max_clicks,
		clicks: Number(row.clicks ?? 0)
	});
	if (reason) return {
		kind: "blocked",
		reason
	};
	if (row.password_hash) {
		if (!data.password) return { kind: "password" };
		if (await sha256(data.password) !== row.password_hash) return { kind: "bad_password" };
	}
	let device = "desktop";
	let browser = "Other";
	let referrer = "";
	try {
		const { getRequest } = await import("./ssr.mjs").then((n) => n.c).then((n) => n.t);
		const req = getRequest();
		const parsed = parseUserAgent(req.headers.get("user-agent") ?? "");
		device = parsed.device;
		browser = parsed.browser;
		referrer = req.headers.get("referer") ?? "";
	} catch {}
	await sql`
      insert into clicks (id, link_id, device, browser, referrer)
      values (${randomId(10)}, ${row.id}, ${device}, ${browser}, ${referrer})
    `;
	return {
		kind: "ok",
		url: row.original_url
	};
});
var getLinkAnalytics_createServerFn_handler = createServerRpc({
	id: "5e1e26004558890ef1699c377b99e99cb9af15aa6de2ca1c3148dc62deb1e57b",
	name: "getLinkAnalytics",
	filename: "src/lib/server/links.ts"
}, (opts) => getLinkAnalytics.__executeServer(opts));
var getLinkAnalytics = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(getLinkAnalytics_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const link = (await sql`
      select l.id, l.user_id, l.short_code, l.original_url, l.password_hash, l.status,
             l.expires_at, l.max_clicks, l.created_at,
             (select count(*)::int from clicks c where c.link_id = l.id) as clicks
      from links l
      where l.id = ${data.id} and l.user_id = ${context.userId}
    `)[0];
	if (!link) throw new Error("Link not found.");
	const clickRows = await sql`
      select created_at, device, browser from clicks where link_id = ${data.id} order by created_at asc
    `;
	const now = Date.now();
	const day = 864e5;
	const series = [];
	for (let i = 13; i >= 0; i--) {
		const key = (/* @__PURE__ */ new Date(now - i * day)).toISOString().slice(0, 10);
		series.push({
			day: key,
			count: 0
		});
	}
	const byDay = new Map(series.map((s) => [s.day, s]));
	const devices = {};
	const browsers = {};
	let today = 0;
	let week = 0;
	for (const c of clickRows) {
		const ts = new Date(c.created_at).getTime();
		const key = new Date(c.created_at).toISOString().slice(0, 10);
		const bucket = byDay.get(key);
		if (bucket) bucket.count += 1;
		if (now - ts < day) today += 1;
		if (now - ts < 7 * day) week += 1;
		const dvc = c.device || "other";
		const b = c.browser || "Other";
		devices[dvc] = (devices[dvc] ?? 0) + 1;
		browsers[b] = (browsers[b] ?? 0) + 1;
	}
	return {
		link: mapLink(link),
		total: clickRows.length,
		unique: new Set(clickRows.map((c) => `${c.browser}|${c.device}`)).size,
		today,
		week,
		series,
		devices: Object.entries(devices).map(([label, count]) => ({
			label,
			count
		})).sort((a, b) => b.count - a.count),
		browsers: Object.entries(browsers).map(([label, count]) => ({
			label,
			count
		})).sort((a, b) => b.count - a.count)
	};
});
//#endregion
export { createLink_createServerFn_handler, deleteLink_createServerFn_handler, getLinkAnalytics_createServerFn_handler, listLinks_createServerFn_handler, resolveShortLink_createServerFn_handler, shortenPublic_createServerFn_handler, toggleLink_createServerFn_handler };
