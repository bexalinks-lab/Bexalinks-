import { r as createServerFn } from "./ssr.mjs";
import { D as _enum, F as object, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-zKRKBNQv.mjs";
import { t as authMiddleware } from "./middleware-hy77NTFs.mjs";
import { n as createSsrRpc } from "./createSsrRpc-DqoCRc_G.mjs";
import { n as planById } from "./plans-BcK06FWz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-BmeAM3-D.js
async function ensureProfile(userId) {
	await (await getSql())`insert into profiles (user_id, plan) values (${userId}, 'free') on conflict (user_id) do nothing`;
}
async function getPlanForUser(userId) {
	const sql = await getSql();
	await ensureProfile(userId);
	const id = (await sql`select plan from profiles where user_id = ${userId}`)[0]?.plan ?? "free";
	return planById(id).id;
}
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("bbc1c4ac15d24002410ca4e216d0bd6701f196f5125f7218f06d0016e85354a7"));
var saveProfileName = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ name: string().trim().max(80) })).handler(createSsrRpc("e8511bf8658539521ddfda03991ba20f4091a7e84753529a476cf20cb77a5e82"));
var setPlan = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ planId: _enum([
	"free",
	"pro",
	"business"
]) })).handler(createSsrRpc("66f53ade48d619ceecc4cdf934e61b110ca3ddae6c656ed2d8efb8c8a3860cff"));
//#endregion
export { setPlan as a, saveProfileName as i, getPlanForUser as n, getWorkspace as r, ensureProfile as t };
