import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as Plus } from "../_libs/lucide-react.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { h as listLinks } from "./router-iP6mcR_i.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { t as Skeleton } from "./skeleton-DFlRoMjn.mjs";
import { t as Input } from "./input-CLVrXCRj.mjs";
import { n as LinksTable, r as QrDialog, t as CreateLinkDialog } from "./qr-dialog-CGQxOJhc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/links-suA3H4Xh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LinksPage() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [qr, setQr] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const links = useQuery({
		queryKey: ["links", query],
		queryFn: () => listLinks({ data: { query } })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Links"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Every short path in this workspace."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New link"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: query,
				onChange: (e) => setQuery(e.target.value),
				placeholder: "Search destination or alias…",
				className: "max-w-sm"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]",
			children: links.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinksTable, {
				links: links.data ?? [],
				onChange: () => void links.refetch(),
				onQr: setQr
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateLinkDialog, {
			open,
			onOpenChange: setOpen,
			onCreated: () => void links.refetch()
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrDialog, {
			code: qr,
			open: !!qr,
			onOpenChange: (o) => !o && setQr(null)
		})
	] });
}
//#endregion
export { LinksPage as component };
