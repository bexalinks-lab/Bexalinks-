import { r as createServerFn } from "./ssr.mjs";
import { F as object, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-zKRKBNQv.mjs";
import { t as authMiddleware } from "./middleware-hy77NTFs.mjs";
import { o as randomId, s as sha256, t as apiSecret } from "./createSsrRpc-DqoCRc_G.mjs";
import { n as planById } from "./plans-BcK06FWz.mjs";
import { n as getPlanForUser, t as ensureProfile } from "./profile-BmeAM3-D.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/keys-BGabaaLG.js
var listApiKeys_createServerFn_handler = createServerRpc({
	id: "1fa12f5a751cfbc95d1339462115faffbda6465b0640fe20eed58dd402515e42",
	name: "listApiKeys",
	filename: "src/lib/server/keys.ts"
}, (opts) => listApiKeys.__executeServer(opts));
var listApiKeys = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listApiKeys_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select id, prefix, uses, created_at from api_keys where user_id = ${context.userId} order by created_at desc
    `).map((r) => ({
		id: r.id,
		prefix: r.prefix,
		uses: Number(r.uses ?? 0),
		createdAt: r.created_at instanceof Date ? r.created_at.toISOString() : String(r.created_at)
	}));
});
var createApiKey_createServerFn_handler = createServerRpc({
	id: "3cdc4bd28b323b2f3b9e1eefcf9f79f5ff55e983b91e8caa0d2649c3a70b1b3e",
	name: "createApiKey",
	filename: "src/lib/server/keys.ts"
}, (opts) => createApiKey.__executeServer(opts));
var createApiKey = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createApiKey_createServerFn_handler, async ({ context }) => {
	await ensureProfile(context.userId);
	if (!planById(await getPlanForUser(context.userId)).limits.api) throw new Error("API access requires the Pro or Business plan.");
	const secret = apiSecret();
	const id = randomId(8);
	const prefix = `${secret.slice(0, 12)}…`;
	await (await getSql())`
      insert into api_keys (id, user_id, key_hash, prefix, uses)
      values (${id}, ${context.userId}, ${await sha256(secret)}, ${prefix}, 0)
    `;
	return {
		id,
		prefix,
		secret
	};
});
var revokeApiKey_createServerFn_handler = createServerRpc({
	id: "fc604686fc92843865a8f06e16f8e3ffac14c0691be0b88fbe74e6c6a073c417",
	name: "revokeApiKey",
	filename: "src/lib/server/keys.ts"
}, (opts) => revokeApiKey.__executeServer(opts));
var revokeApiKey = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(revokeApiKey_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`delete from api_keys where id = ${data.id} and user_id = ${context.userId}`;
	return { ok: true };
});
//#endregion
export { createApiKey_createServerFn_handler, listApiKeys_createServerFn_handler, revokeApiKey_createServerFn_handler };
