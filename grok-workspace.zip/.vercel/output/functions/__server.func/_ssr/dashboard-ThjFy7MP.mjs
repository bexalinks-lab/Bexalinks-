import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as Plus } from "../_libs/lucide-react.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { h as listLinks, l as formatNumber } from "./router-iP6mcR_i.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { t as Skeleton } from "./skeleton-DFlRoMjn.mjs";
import { r as getWorkspace } from "./profile-BmeAM3-D.mjs";
import { t as Input } from "./input-CLVrXCRj.mjs";
import { n as LinksTable, r as QrDialog, t as CreateLinkDialog } from "./qr-dialog-CGQxOJhc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-ThjFy7MP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DashboardPage() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [qr, setQr] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const workspace = useQuery({
		queryKey: ["workspace"],
		queryFn: () => getWorkspace()
	});
	const links = useQuery({
		queryKey: ["links"],
		queryFn: () => listLinks({ data: { query: "" } })
	});
	const filtered = (links.data ?? []).filter((l) => !query || l.shortCode.toLowerCase().includes(query.toLowerCase()) || l.originalUrl.toLowerCase().includes(query.toLowerCase())).slice(0, 8);
	const stats = workspace.data?.stats;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Overview"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: workspace.data ? `${workspace.data.planName} plan` : "Your workspace"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New link"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: workspace.isPending ? Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 rounded-3xl" }, i)) : [
				["Total links", stats?.links ?? 0],
				["Total clicks", stats?.clicks ?? 0],
				["Active", stats?.active ?? 0],
				["Domains", stats?.domains ?? 0]
			].map(([label, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[24px] border border-border bg-card p-5 shadow-[var(--shadow-card)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold tabular-nums",
					children: formatNumber(Number(n))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: label
				})]
			}, String(label)))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-semibold",
					children: "Recent links"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Search…",
					className: "h-9 max-w-[200px] rounded-xl"
				})]
			}), links.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 px-5 pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinksTable, {
				links: filtered,
				dense: true,
				onChange: () => {
					links.refetch();
					workspace.refetch();
				},
				onQr: setQr
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateLinkDialog, {
			open,
			onOpenChange: setOpen,
			onCreated: () => {
				links.refetch();
				workspace.refetch();
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrDialog, {
			code: qr,
			open: !!qr,
			onOpenChange: (o) => !o && setQr(null)
		})
	] });
}
//#endregion
export { DashboardPage as component };
