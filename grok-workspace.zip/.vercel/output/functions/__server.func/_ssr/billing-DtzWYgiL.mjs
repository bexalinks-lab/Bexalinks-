import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-DFlRoMjn.mjs";
import { n as planById } from "./plans-BcK06FWz.mjs";
import { r as getWorkspace } from "./profile-BmeAM3-D.mjs";
import { t as PricingGrid } from "./pricing-grid-B452kHFo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-DtzWYgiL.js
var import_jsx_runtime = require_jsx_runtime();
function BillingPage() {
	const workspace = useQuery({
		queryKey: ["workspace"],
		queryFn: () => getWorkspace()
	});
	const plan = planById(workspace.data?.planId ?? "free");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "Billing"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Plans are applied immediately. No card is charged in this product."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: "Current plan"
			}), workspace.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-3 h-8 w-40" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 font-display text-2xl font-semibold",
				children: [plan.name, plan.price ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ml-2 text-base font-medium text-muted-foreground",
					children: [
						"$",
						plan.price,
						"/mo"
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 text-base font-medium text-muted-foreground",
					children: "no cost"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Change plan"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PricingGrid, { currentPlan: workspace.data?.planId })
			})]
		})
	] });
}
//#endregion
export { BillingPage as component };
