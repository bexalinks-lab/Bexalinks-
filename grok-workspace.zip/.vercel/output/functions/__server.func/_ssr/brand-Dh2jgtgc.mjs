import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { s as cn } from "./router-iP6mcR_i.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/brand-Dh2jgtgc.js
var import_jsx_runtime = require_jsx_runtime();
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid size-8 place-items-center rounded-[10px] bg-primary text-[13px] font-semibold tracking-tight text-primary-foreground", className),
		"aria-hidden": true,
		children: "ln"
	});
}
function Logo({ className, tone = "light" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("flex items-center gap-2.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: tone === "dark" ? "bg-ink-foreground text-ink" : void 0 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-display text-[17px] font-semibold tracking-tight", tone === "dark" ? "text-ink-foreground" : "text-foreground"),
			children: "LinkShort"
		})]
	});
}
//#endregion
export { Logo as t };
