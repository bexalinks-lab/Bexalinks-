import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Check } from "../_libs/lucide-react.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { s as cn } from "./router-iP6mcR_i.mjs";
import { n as useCurrentUserState } from "./use-current-user-DG6UNzh9.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { t as PLANS } from "./plans-BcK06FWz.mjs";
import { a as setPlan } from "./profile-BmeAM3-D.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-grid-B452kHFo.js
var import_jsx_runtime = require_jsx_runtime();
function PricingGrid({ currentPlan }) {
	const { user, isPending } = useCurrentUserState();
	const qc = useQueryClient();
	async function choose(planId) {
		if (isPending) return;
		if (!user) {
			window.location.href = "/register";
			return;
		}
		try {
			await setPlan({ data: { planId } });
			await qc.invalidateQueries({ queryKey: ["workspace"] });
			toast.success(planId === "free" ? "On the Free plan." : `Moved to ${planId}.`);
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not update plan");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 lg:grid-cols-3",
		children: PLANS.map((plan) => {
			const featured = Boolean(plan.featured);
			const active = currentPlan === plan.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("relative flex flex-col rounded-[28px] border bg-card p-7 shadow-[var(--shadow-card)]", featured ? "border-primary" : "border-border"),
				children: [
					featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -top-3 left-6 rounded-full bg-primary px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-primary-foreground",
						children: "Most chosen"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-muted-foreground",
						children: plan.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-display text-4xl font-semibold tracking-tight",
						children: [plan.price === 0 ? "Free" : `$${plan.price}`, plan.price > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 text-sm font-medium text-muted-foreground",
							children: "/mo"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 text-sm font-medium text-muted-foreground",
							children: "forever"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: plan.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 flex flex-1 flex-col gap-2.5 text-sm",
						children: plan.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-success" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: f })]
						}, f))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-8 w-full",
						variant: featured ? "default" : "outline",
						onClick: () => void choose(plan.id),
						disabled: active,
						children: active ? "Current plan" : plan.price === 0 ? "Start free" : `Choose ${plan.name}`
					}),
					!user && !isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-center text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "underline-offset-2 hover:underline",
								children: "Log in"
							}),
							" ",
							"to apply a plan to your workspace."
						]
					}) : null
				]
			}, plan.id);
		})
	});
}
//#endregion
export { PricingGrid as t };
