import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-D7C9LyJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-CtU1pqRG.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-2xl px-5 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-semibold",
					children: "Terms"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 space-y-4 text-sm leading-relaxed text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Use LinkShort for lawful destinations only. Do not shorten malware, phishing, or content that impersonates another party." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Plans and upgrades in this product are simulated — no real charges are processed." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We may disable a short path that is reported as abusive. You can pause or delete your own links at any time from the workspace." })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { TermsPage as component };
