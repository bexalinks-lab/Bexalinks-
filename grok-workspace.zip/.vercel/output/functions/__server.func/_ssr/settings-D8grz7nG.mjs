import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as useCurrentUser } from "./use-current-user-DG6UNzh9.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { i as saveProfileName, r as getWorkspace } from "./profile-BmeAM3-D.mjs";
import { t as Input } from "./input-CLVrXCRj.mjs";
import { t as Label } from "./label-CDr0-t28.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-D8grz7nG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const user = useCurrentUser();
	const workspace = useQuery({
		queryKey: ["workspace"],
		queryFn: () => getWorkspace()
	});
	const [name, setName] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (workspace.data?.name) setName(workspace.data.name);
		else if (user?.displayName) setName(user.displayName);
	}, [workspace.data, user]);
	async function save() {
		try {
			await saveProfileName({ data: { name } });
			toast.success("Settings saved");
			workspace.refetch();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not save");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "Account"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "How you appear in this workspace."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 max-w-md space-y-4 rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "name",
					children: "Name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "name",
					value: name,
					onChange: (e) => setName(e.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "email",
					children: "Email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "email",
					value: user?.primaryEmail ?? "",
					disabled: true
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void save(),
					children: "Save changes"
				})
			]
		})
	] });
}
//#endregion
export { SettingsPage as component };
