import { r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-zKRKBNQv.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stats-JJHd77Cm.js
var getPlatformStats_createServerFn_handler = createServerRpc({
	id: "db9ccbc68c738f3dead78d6712e6b27424b1b0a201e02ce14f20ff4c518fdec4",
	name: "getPlatformStats",
	filename: "src/lib/server/stats.ts"
}, (opts) => getPlatformStats.__executeServer(opts));
var getPlatformStats = createServerFn({ method: "GET" }).handler(getPlatformStats_createServerFn_handler, async () => {
	const sql = await getSql();
	const [{ links }] = await sql`select count(*)::int as links from links`;
	const [{ clicks }] = await sql`select count(*)::int as clicks from clicks`;
	const [{ workspaces }] = await sql`select count(*)::int as workspaces from profiles`;
	const [{ active }] = await sql`select count(*)::int as active from links where status = 'active'`;
	return {
		links: Number(links ?? 0),
		clicks: Number(clicks ?? 0),
		workspaces: Number(workspaces ?? 0),
		active: Number(active ?? 0)
	};
});
//#endregion
export { getPlatformStats_createServerFn_handler };
