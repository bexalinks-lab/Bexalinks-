import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-D7C9LyJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-B-wE-wNv.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-2xl px-5 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-semibold",
					children: "Privacy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 space-y-4 text-sm leading-relaxed text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "LinkShort stores the destination you submit, the short code we issue, and click metadata (time, device class, browser family, referrer). We do not sell this." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Accounts use Google, X, or email and password. Your workspace data is scoped to your signed-in identity. Guest links created on the home page are unowned public redirects." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Passwords on gated links are stored as hashes, never in the clear." })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { PrivacyPage as component };
