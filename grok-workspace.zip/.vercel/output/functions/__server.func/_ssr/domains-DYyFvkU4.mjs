import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { F as object, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { t as authMiddleware } from "./middleware-hy77NTFs.mjs";
import { n as createSsrRpc } from "./createSsrRpc-DqoCRc_G.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { t as Skeleton } from "./skeleton-DFlRoMjn.mjs";
import { r as getWorkspace } from "./profile-BmeAM3-D.mjs";
import { t as Input } from "./input-CLVrXCRj.mjs";
import { t as Badge } from "./badge-DQZDnHgg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/domains-DYyFvkU4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var listDomains = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("eb3bae0a0ae595dd95004bcb493dadf924da9cac50781f6cce27900429b364de"));
var addDomain = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ domain: string().trim().min(3).max(120) })).handler(createSsrRpc("739edf1db12ac2ce3a4be56a5cbbe41cd481d6a33714556d277c184c60af1cc8"));
var verifyDomain = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(createSsrRpc("ee4f46ed20fccadb23c5931b3b592df79f98a079f94b33ac3f4e03e10c1299e3"));
var removeDomain = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ id: string() })).handler(createSsrRpc("7a36ef2f7b05f2fc25e16dab4231dda0c7f58fc4f52e48b5060c5b67d9058468"));
function DomainsPage() {
	const [domain, setDomain] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const list = useQuery({
		queryKey: ["domains"],
		queryFn: () => listDomains()
	});
	const workspace = useQuery({
		queryKey: ["workspace"],
		queryFn: () => getWorkspace()
	});
	const canAdd = (workspace.data?.limits.domains ?? 0) > 0;
	async function add() {
		setBusy(true);
		try {
			await addDomain({ data: { domain } });
			setDomain("");
			toast.success("Domain added — verify DNS, then mark active.");
			list.refetch();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not add domain");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "Custom domains"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Point a hostname at LinkShort and serve short paths on your own brand."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-[24px] border border-border bg-card p-6 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Connect a domain"
				}),
				!canAdd && workspace.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: [
						"Custom domains require Pro or Business.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/billing",
							className: "font-semibold text-primary hover:underline",
							children: "Upgrade plan"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-2 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: domain,
						onChange: (e) => setDomain(e.target.value),
						placeholder: "links.yourbrand.com"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void add(),
						disabled: busy,
						children: "Add domain"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-5 overflow-x-auto rounded-2xl bg-ink p-5 font-mono text-[13px] leading-relaxed text-ink-foreground",
					children: `Type     CNAME
Name     links
Target   edge.lnk.sh`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted-foreground",
					children: "Add the record at your DNS provider, then click Verify. This preview treats verification as a confirmation step."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-6 pt-5 text-sm font-semibold",
				children: "Your domains"
			}), list.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })
			}) : !list.data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-6 py-12 text-center text-sm text-muted-foreground",
				children: "No custom domains connected yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "mt-2 w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-6 pb-2 text-left font-semibold",
							children: "Domain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 pb-2 text-left font-semibold",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-6 pb-2" })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: list.data.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-6 py-3 font-mono text-[13px]",
							children: d.domain
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: d.status === "active" ? "success" : "muted",
								children: d.status
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-6 py-3 text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2",
								children: [d.status !== "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => void verifyDomain({ data: { id: d.id } }).then(() => {
										toast.success("Domain verified");
										list.refetch();
									}).catch((e) => toast.error(e instanceof Error ? e.message : "Failed")),
									children: "Verify"
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => void removeDomain({ data: { id: d.id } }).then(() => {
										toast.success("Domain removed");
										list.refetch();
									}).catch((e) => toast.error(e instanceof Error ? e.message : "Failed")),
									children: "Remove"
								})]
							})
						})
					]
				}, d.id)) })]
			})]
		})
	] });
}
//#endregion
export { DomainsPage as component };
