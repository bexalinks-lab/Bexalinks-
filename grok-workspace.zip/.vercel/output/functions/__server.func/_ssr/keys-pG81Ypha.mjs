import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as formatDate, i as revokeApiKey, n as createApiKey, r as listApiKeys } from "./router-iP6mcR_i.mjs";
import { t as Button } from "./button-BKFq4Z1C.mjs";
import { t as Skeleton } from "./skeleton-DFlRoMjn.mjs";
import { r as getWorkspace } from "./profile-BmeAM3-D.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/keys-pG81Ypha.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function KeysPage() {
	const list = useQuery({
		queryKey: ["keys"],
		queryFn: () => listApiKeys()
	});
	const workspace = useQuery({
		queryKey: ["workspace"],
		queryFn: () => getWorkspace()
	});
	const [secret, setSecret] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const can = Boolean(workspace.data?.limits.api);
	async function generate() {
		setBusy(true);
		try {
			const res = await createApiKey();
			setSecret(res.secret);
			toast.success("New key generated — copy it now.");
			list.refetch();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not create key");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "API keys"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Bearer tokens for POST /api/v1/shorten."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void generate(),
				disabled: busy || !can,
				children: "Generate key"
			})]
		}),
		!can && workspace.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm text-muted-foreground",
			children: [
				"API access requires Pro or Business.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/billing",
					className: "font-semibold text-primary hover:underline",
					children: "Upgrade"
				})
			]
		}) : null,
		secret ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-[24px] border border-primary/30 bg-primary/5 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Copy this key. It will not be shown again."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 break-all font-mono text-sm",
					children: secret
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					className: "mt-3",
					variant: "secondary",
					onClick: () => {
						navigator.clipboard.writeText(secret);
						toast.success("Copied");
					},
					children: "Copy"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 overflow-hidden rounded-[24px] border border-border bg-card shadow-[var(--shadow-card)]",
			children: list.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })
			}) : !list.data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-6 py-12 text-center text-sm text-muted-foreground",
				children: "No API keys yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-6 py-3 text-left font-semibold",
							children: "Key"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-3 text-left font-semibold",
							children: "Created"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-3 text-left font-semibold",
							children: "Requests"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-6 py-3" })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: list.data.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-6 py-3 font-mono text-[13px]",
							children: k.prefix
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-3 text-muted-foreground",
							children: formatDate(k.createdAt)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-3 tabular-nums",
							children: k.uses
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-6 py-3 text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => void revokeApiKey({ data: { id: k.id } }).then(() => {
									toast.success("Key revoked");
									list.refetch();
								}).catch((e) => toast.error(e instanceof Error ? e.message : "Failed")),
								children: "Revoke"
							})
						})
					]
				}, k.id)) })]
			})
		})
	] });
}
//#endregion
export { KeysPage as component };
