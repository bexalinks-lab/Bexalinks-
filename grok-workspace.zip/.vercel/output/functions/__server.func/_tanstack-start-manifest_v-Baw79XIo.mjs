//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Baw79XIo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/_app",
			"/admin",
			"/developers",
			"/forgot",
			"/login",
			"/pricing",
			"/privacy",
			"/register",
			"/terms",
			"/s/$code",
			"/api/auth/$",
			"/api/v1/shorten"
		],
		preloads: [
			"/assets/index-DfvHwGXd.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/react-dom-x9LNwWQc.js",
			"/assets/createServerFn-CWkGs9-7.js",
			"/assets/utils-BRieW3Dc.js",
			"/assets/link-DgTRm1Wh.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/useMatch-BvnUZTsx.js",
			"/assets/lazyRouteComponent-CAoImu89.js",
			"/assets/middleware-KivuWwIy.js",
			"/assets/links-D_rGJfNM.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DfvHwGXd.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CwDGJQL7.js",
			"/assets/pricing-grid-CCGMn-YR.js",
			"/assets/qr-code-CKp-nztX.js",
			"/assets/key-round-jfjiZ7RL.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/button-DxHwdoK8.js",
			"/assets/input-DWZT0ar8.js",
			"/assets/site-footer--qWeGKh1.js"
		]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/billing",
			"/_app/dashboard",
			"/_app/domains",
			"/_app/keys",
			"/_app/links",
			"/_app/settings"
		],
		preloads: [
			"/assets/_app-YQtZkWWh.js",
			"/assets/chart-column-lq_cL8TH.js",
			"/assets/key-round-jfjiZ7RL.js",
			"/assets/sheet-BJTnLxtI.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/brand-DkX-NArf.js",
			"/assets/button-DxHwdoK8.js",
			"/assets/skeleton-DBexTeba.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DdDHyIWu.js",
			"/assets/useQuery-DP9oV8WM.js",
			"/assets/skeleton-DBexTeba.js",
			"/assets/site-footer--qWeGKh1.js"
		]
	},
	"/developers": {
		filePath: "/workspace/src/routes/developers.tsx",
		children: void 0,
		preloads: [
			"/assets/developers-BD0QmbtG.js",
			"/assets/button-DxHwdoK8.js",
			"/assets/site-footer--qWeGKh1.js"
		]
	},
	"/forgot": {
		filePath: "/workspace/src/routes/forgot.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-DO8dFbfr.js",
			"/assets/brand-DkX-NArf.js",
			"/assets/button-DxHwdoK8.js",
			"/assets/input-DWZT0ar8.js",
			"/assets/label-CmCJ0sFa.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-rUqwdnjW.js",
			"/assets/useNavigate-CBdiv7Lb.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/providers-R25ah5Ot.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/brand-DkX-NArf.js",
			"/assets/button-DxHwdoK8.js",
			"/assets/skeleton-DBexTeba.js",
			"/assets/input-DWZT0ar8.js",
			"/assets/label-CmCJ0sFa.js"
		]
	},
	"/pricing": {
		filePath: "/workspace/src/routes/pricing.tsx",
		children: void 0,
		preloads: [
			"/assets/pricing-CBw8IOjR.js",
			"/assets/pricing-grid-CCGMn-YR.js",
			"/assets/site-footer--qWeGKh1.js"
		]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-BY2fu_ta.js", "/assets/site-footer--qWeGKh1.js"]
	},
	"/register": {
		filePath: "/workspace/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-CcTFtTG6.js",
			"/assets/useNavigate-CBdiv7Lb.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/providers-R25ah5Ot.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/brand-DkX-NArf.js",
			"/assets/button-DxHwdoK8.js",
			"/assets/skeleton-DBexTeba.js",
			"/assets/input-DWZT0ar8.js",
			"/assets/label-CmCJ0sFa.js"
		]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-C3v__v8u.js", "/assets/site-footer--qWeGKh1.js"]
	},
	"/_app/billing": {
		filePath: "/workspace/src/routes/_app/billing.tsx",
		children: void 0,
		preloads: [
			"/assets/billing-BOC-P3eQ.js",
			"/assets/pricing-grid-CCGMn-YR.js",
			"/assets/useQuery-DP9oV8WM.js",
			"/assets/profile-yLhHcbfg.js"
		]
	},
	"/_app/dashboard": {
		filePath: "/workspace/src/routes/_app/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-DFBq_A9g.js",
			"/assets/qr-dialog-BVgSTsh5.js",
			"/assets/useQuery-DP9oV8WM.js",
			"/assets/profile-yLhHcbfg.js",
			"/assets/input-DWZT0ar8.js"
		]
	},
	"/_app/domains": {
		filePath: "/workspace/src/routes/_app/domains.tsx",
		children: void 0,
		preloads: [
			"/assets/domains-CA80aQq9.js",
			"/assets/useQuery-DP9oV8WM.js",
			"/assets/profile-yLhHcbfg.js",
			"/assets/input-DWZT0ar8.js",
			"/assets/badge-DZnUCAJA.js"
		]
	},
	"/_app/keys": {
		filePath: "/workspace/src/routes/_app/keys.tsx",
		children: void 0,
		preloads: [
			"/assets/keys-Baa8S7xB.js",
			"/assets/useQuery-DP9oV8WM.js",
			"/assets/profile-yLhHcbfg.js"
		]
	},
	"/_app/links": {
		filePath: "/workspace/src/routes/_app/links.tsx",
		children: ["/_app/links/$id"],
		preloads: [
			"/assets/links-Dvc-HZLY.js",
			"/assets/qr-dialog-BVgSTsh5.js",
			"/assets/useQuery-DP9oV8WM.js",
			"/assets/input-DWZT0ar8.js"
		]
	},
	"/_app/settings": {
		filePath: "/workspace/src/routes/_app/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-v0ZLzqf9.js",
			"/assets/useQuery-DP9oV8WM.js",
			"/assets/profile-yLhHcbfg.js",
			"/assets/input-DWZT0ar8.js",
			"/assets/label-CmCJ0sFa.js"
		]
	},
	"/s/$code": {
		filePath: "/workspace/src/routes/s.$code.tsx",
		children: void 0,
		preloads: [
			"/assets/s._code-Bd7_Rhen.js",
			"/assets/brand-DkX-NArf.js",
			"/assets/button-DxHwdoK8.js",
			"/assets/input-DWZT0ar8.js",
			"/assets/label-CmCJ0sFa.js"
		]
	},
	"/_app/links/$id": {
		filePath: "/workspace/src/routes/_app/links.$id.tsx",
		children: void 0,
		preloads: ["/assets/links._id-BIKI8Od_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
